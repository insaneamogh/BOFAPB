import { LightningElement, api, wire, track } from 'lwc';
import askAgentInvocable from '@salesforce/apex/AF_AgentInvocationService.AF_InvokeAgent';
import getMeetingNoteActionReviewDetails from '@salesforce/apex/AF_MeetingNoteActionHandler.getMeetingNoteActionReviewDetails';
import getUserNameById from '@salesforce/apex/AF_TaskManageAction.getUserNameById';
import getTask from '@salesforce/apex/AF_TaskDataController.getTask';
import { subscribe } from 'lightning/empApi';
import { refreshApex } from '@salesforce/apex';
import runAction from '@salesforce/apex/AF_MeetingNoteActionRunner.runAction';

export default class AFAgentforceFollowUpActions extends LightningElement {
      @api recordId;
    @track task;
    @track error;
    description = '';
    response;
    @api channelName = '/event/Task_Updated__e';
    @track isLoading = false;
    wiredTaskData;

    @track reviewFields = [];     // [{ name, value }]
     @track actionReviews = [];          // meta (incl. AF_Object_Name__c)
    @track showReviewScreen = false;
    @track createdRecordLabel;
    @track createdRecordId;
    @track submitSuccess = false;
    @track submitError;
    
    @wire(getTask, { recordId: '$recordId', description : '$description' })
        wiredTask({ error, data }) {
            this.wiredTaskData = data;
            if (data) {
                this.task = data;
                this.description = data.Description || '';
                console.log('Desc',this.description);
                // this.whoId = data.WhoId || '';
                // this.buttonDisabled = this.description.trim().length === 0 || !this.whoId;
            } else if (error) {
                this.error = error;
                // this.buttonDisabled = true;
            } else {
                // this.buttonDisabled = true;
            }
        }  
    extractTempActionId(responseText) {
    const match = responseText.match(/Temporary Action ID: "?([a-zA-Z0-9]{15,18})"?/i);
    console.log('match',match);
    return match ? match[1] : null;
    }

    async handleReviewFields(fields) {
    // Deep copy to avoid mutating original
    let updatedFields = fields.map(f => ({...f}));
    for (let field of updatedFields) {
        if(field.name === 'OwnerId' && field.value) {
            field.name = 'Assigned To'; 
            try {
                const userName = await getUserNameById({ userId: field.value });
                field.value = userName; // Replace id with name
            } catch(e) {
                // Leave value as Id if lookup fails
            }
        }
    }
    this.reviewFields = updatedFields;
}
    

    // Call the Apex class, passing the current Description
    invokeAgentforce() {
        this.submitSuccess = false;
        this.submitError = undefined;
        this.createdRecordLabel = undefined;
        this.createdRecordId = undefined;
        refreshApex(this.wiredTaskData);
        console.log('this.description in invoke button: ',this.description);
        this.isLoading = true;
        askAgentInvocable({ taskId: this.recordId, prompt: this.description })
            .then(res => {
                 console.log('response1',res);
                let parsedObj = res;
                 console.log('response2',parsedObj);
                // Handle both string and object responses
                if (typeof parsedObj === 'string') {
                    try {
                        parsedObj = JSON.parse(parsedObj);
                    } catch (e) {
                        this.response = 'Agentforce response could not be parsed.';
                        return;
                    }
                }
                // Display agent's value
                this.response = parsedObj && parsedObj.value ? parsedObj.value : 'Agent did not respond as expected.';
                console.log('response3',this.response);
                //const tempActionId = this.extractTempActionId(this.response);// Just ensure your response includes this!
                //console.log('tempActionId',tempActionId);
                //if (tempActionId) {
                    // Fetch review details for temp action record
                    getMeetingNoteActionReviewDetails({ taskId: this.recordId })
                        .then(result => {
                            //this.reviewFields = result.fields;      // [{name, value}]
                              //this.handleReviewFields(result.fields);
                            this.actionReviews = result;      // meta details for header
                            this.showReviewScreen = true;           // show the approval UI!
                        })
                        .catch(err => {
                            this.response = 'Failed to fetch review details: ' + (err.body?.message || err.message);
                        });
                //} 
                this.isLoading = false;
            })
            
            .catch(err => {
                this.isLoading = false;
                this.response = 'Agentforce call failed: ' + (err?.body?.message || err.message || err);
                console.error('Agentforce call failed:', err);
            });
    }

    async handleSubmit(event) {
        const idx = event.target.dataset.index;
        const actionReview = this.actionReviews[idx];
        if (!actionReview) return;

        // Build fields: use apiName for submission
        const fields = {};
        actionReview.fields.forEach(fld => {
            fields[fld.apiName] = fld.value !== '' && fld.value !== undefined ? fld.value : null;
        });
        const objectApiName = actionReview.action.AF_Object_Name__c;

        this.submitError = undefined;
        this.isLoading = true;
        try {
            const result = await runAction({
                objectApiName: objectApiName,
                fieldValues: fields,
                taskId: this.recordId
            });
            if (result.errorMessage) {
                this.submitError = result.errorMessage;
                this.submitSuccess = false;
            } else {
                this.createdRecordLabel = result.objectLabel;
                this.createdRecordId = result.recordId;
                this.submitSuccess = true;
            }
        } catch(error) {
            this.submitError = error.body ? error.body.message : error.message;
            this.submitSuccess = false;
        }
        this.isLoading = false;
    }
    get createdRecordUrl() {
        return this.createdRecordId ? `/${this.createdRecordId}` : '#';
    }



////////////////////////////////////////////////////////////////////////

    
 
    connectedCallback() {
        //this.handleSubscribe();
        const self = this;
         console.log('callbackFuction');
        const callbackFuction = function (response) {
            console.log('callbackFuction',JSON.stringify(response));
            self.refreshMyData();
        }

       subscribe(this.channelName, -1, callbackFuction)
    .then(response => {
        console.log('Subscription request sent to: ', JSON.stringify(response.channel));
    })
    .catch(err => {
        console.error('EMP API subscription failed', err);
    });        
    }

    refreshMyData(){
        refreshApex(this.wiredTask).then(() =>{
            console.log('REfreshing data');
        });
    }    

}