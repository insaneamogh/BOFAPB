import { LightningElement, api, wire, track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

export default class CpMeetingPrepMainComponent extends LightningElement {
    // This will bind to Salesforce record context automatically
    @api recordId;
    @track showModal = true;
    @track meetingType;
    @track meetingPurpose = '';
    @track selectedDataCategories = [];
    @track showMeetingPrep = false;
    @track fallbackRecordId;
    @track isLoadingSummary = false;

    // This will wire the current page info if recordId is not set by Salesforce
    @wire(CurrentPageReference)
    setCurrentPageReference(currentPageReference) {
        if (!this.recordId && currentPageReference && currentPageReference.attributes && currentPageReference.attributes.recordId) {
            this.fallbackRecordId = currentPageReference.attributes.recordId;
        }
    }

    get effectiveRecordId() {
        return this.recordId || this.fallbackRecordId;
    }

    meetingTypeOptions = [
        { label: 'Quarterly check in', value: 'Quarterly check in' },
        { label: 'Adhoc', value: 'Adhoc' }
    ];

    // Available data categories that users can select for Ad Hoc meetings
    dataCategoryOptions = [
        { label: 'Financial Summary', value: 'FinancialSummary', selected: true },
        { label: 'Opportunities', value: 'Opportunities', selected: true },
        { label: 'Employment Information', value: 'Employment', selected: false },
        { label: 'Education Information', value: 'Education', selected: false },
        { label: 'Meaningful Interactions', value: 'MeaningfulInteractions', selected: true },
        { label: 'Client Service Interactions', value: 'ClientServiceInteractions', selected: false }
    ];

    connectedCallback() {
        // Initialize selected categories based on default selections
        this.updateSelectedCategories();
    }

    handleMeetingTypeChange(event) {
        this.meetingType = event.detail.value;
        // Reset meeting purpose when meeting type changes
        if (this.meetingType !== 'Adhoc') {
            this.meetingPurpose = '';
        }
        // Update selected categories array
        this.updateSelectedCategories();
    }

    handleMeetingPurposeChange(event) {
        this.meetingPurpose = event.detail.value;
    }

    handleDataCategoryChange(event) {
        const categoryValue = event.target.value;
        const isChecked = event.target.checked;

        // Update the selected state in dataCategoryOptions
        this.dataCategoryOptions = this.dataCategoryOptions.map(option => {
            if (option.value === categoryValue) {
                return { ...option, selected: isChecked };
            }
            return option;
        });

        // Update the selectedDataCategories array
        this.updateSelectedCategories();
    }

    updateSelectedCategories() {
        this.selectedDataCategories = this.dataCategoryOptions
            .filter(option => option.selected)
            .map(option => option.value);
    }

    get showMeetingPurposeInput() {
        return this.meetingType === 'Adhoc';
    }

    get isSaveDisabled() {
        return !this.meetingType || (this.meetingType === 'Adhoc' && !this.meetingPurpose.trim());
    }

    handleCancel() {
        this.showModal = false;
        this.showMeetingPrep = false;
    }

    handleSave() {
        this.showModal = false;
        this.isLoadingSummary = true;
        // Show meeting prep for both meeting types
        this.showMeetingPrep = true;
    }

     handleSummaryLoaded() {
        this.isLoadingSummary = false;
    }
}