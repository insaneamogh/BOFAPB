import { LightningElement, api } from 'lwc';
import askAgent from '@salesforce/apex/PB_Advisor.askAgent';

export default class MeetingPrepComponent extends LightningElement {
    @api recordId;
    meetingType = 'Quarterly';
    meetingDate = '90 days';
    isLoading = false;
    response = '';
    error = '';

    meetingTypeOptions = [
        { label: 'Quarterly', value: 'Quarterly' },
        { label: 'Adhoc', value: 'Adhoc' }
    ];
    meetingDateOptions = [
        { label: '90 days', value: '90 days' },
        { label: '60 days', value: '60 days' },
        { label: '30 days', value: '30 days' }
    ];

    handleMeetingTypeChange(event) {
        this.meetingType = event.detail.value;
    }

    handleMeetingDateChange(event) {
        this.meetingDate = event.detail.value;
    }

    async handleGenerateClick() {
        this.isLoading = true;
        this.response = '';
        this.error = '';

        try {
            // For demo, using recordId as the only Party ID; replace with logic for household if needed!
            let partyIds = [this.recordId];
            const result = await askAgent({
                userMessage: 'Summarise my Account 001gL00000RCDA6QAP'
             /*   partyIds: partyIds,
                meetingType: this.meetingType,
                meetingDate: this.meetingDate*/
            });
            // Result is JSON string - parse for display
            let parsed = JSON.parse(result);
            if (typeof parsed === 'string') {
                this.response = parsed;
            } else if (Array.isArray(parsed)) {
                this.response = parsed.join('; ');
            } else {
                this.response = JSON.stringify(parsed);
            }
        } catch (e) {
            this.error = e.body && e.body.message ? e.body.message : e.message;
        }
        this.isLoading = false;
    }
}