import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import initData from '@salesforce/apex/UST_Agentforce_MeetingPrepComtroller.initData';
import getSummary from '@salesforce/apex/UST_Agentforce_MeetingPrepComtroller.getSummary';

export default class UST_Agentforce_MeetingPrep extends NavigationMixin(LightningElement) {
     _recordId;
     _hasInit = false;
    @api meetingType; // Accept meeting type from parent
    @api meetingPurpose; // Accept meeting purpose from parent
    @api meetingTitle;
    @api selectedDataCategories; // Accept selected data categories from parent
    @track correlationId;
    @track payloadJSON;
    @track error;
     @track summaryText = '';
    @track summaryError = '';
    @track summaryRendered = false;
    @track isLoadingSummary = false;
    @track isLoadingData = false;
    @track showModal = false;
    @track modalRecordId = '';
    @track modalObjectApiName = '';
    @track modalError = '';
    @track parsedDataCategories = {};
    @track displayConfig = {
        cards: [],
        accordions: []
    };

     @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        if (value && !this._hasInit) {
            this._hasInit = true;
            this.fetchInitData();
        }
    }

    get isAdhocLoad() {
    return this.meetingType === 'Adhoc';
    }

    fetchInitData() {
        this.isLoadingData = true;
        this.isLoadingSummary = true;
        initData({
            partyId: this.recordId,
            meetingType: 'Quarterly Check-In',
            windowDays: 90
        })
        .then(result => {
            this.correlationId = result.correlationId;
            this.payloadJSON = result.payloadJSON;

            try {
                this.parsePayloadData();
                this.initializeDisplayConfig();
            } catch (processingError) {
                console.error('Error during data processing:', processingError);
                this.error = `Data processing failed: ${processingError.message}`;
            }

            // Data is now ready - stop data loading (always set this to false)
            this.isLoadingData = false;

            // Start AI summary generation independently
            this.handleGetSummary();
        })
        .catch(error => {
            console.error('initData failed:', error);
            this.error = error.body ? error.body.message : error.message;
            this.isLoadingData = false;
            this.isLoadingSummary = false;
        });
    }

     handleGetSummary() {
        // Summary loading is already started in fetchInitData

        // Determine prompt template based on meeting type
        let promptTemplateName = 'CP_Test_Quarterly'; // Default for Quarterly
        if (this.meetingType === 'Adhoc') {
            promptTemplateName = 'CP_Test_Ad_Hoc';
        }

        getSummary({
            payloadJSON: JSON.stringify(this.payloadJSON),
            promptTemplateName: promptTemplateName,
            meetingType: this.meetingType,
            meetingPurpose: this.meetingPurpose,
            selectedDataCategories: this.selectedDataCategories
        })
        .then(result => {
            this.summaryText = result;
            this.summaryError = '';
            this.summaryRendered = false; // Reset to trigger re-rendering
            this.isLoadingSummary = false; // Summary is now ready
            this.dispatchEvent(new CustomEvent('summaryloaded'));
        })
        .catch(error => {
            this.summaryText = '';
            this.summaryError = error.body ? error.body.message : error.message;
            this.isLoadingSummary = false; // Stop loading even on error
            this.dispatchEvent(new CustomEvent('summaryloaded'));
        });
    }

    get prettyPayload() {
        return this.payloadJSON ? JSON.stringify(this.payloadJSON, null, 2) : '';
    }

    // Dynamic data parsing to handle flexible JSON structures with enhanced resilience
    parsePayloadData() {
        if (!this.payloadJSON || !this.payloadJSON.r_PayloadJSON) {
            console.warn('No payload data to parse');
            this.parsedDataCategories = {};
            return;
        }

        try {
            let rawPayload;
            const payloadData = this.payloadJSON.r_PayloadJSON;

            if (typeof payloadData === 'string') {
                console.log('Raw JSON string received:', payloadData.substring(0, 200) + '...');

                // Apply multiple cleanup strategies
                const cleanedJSON = this.cleanupJSON(payloadData);
                console.log('Cleaned JSON:', cleanedJSON.substring(0, 200) + '...');

                try {
                    rawPayload = JSON.parse(cleanedJSON);
                    console.log('Successfully parsed JSON');
                } catch (parseError) {
                    console.error('JSON parsing failed even after cleanup:', parseError);

                    // Try additional fallback strategies
                    rawPayload = this.tryFallbackParsing(payloadData);

                    if (!rawPayload) {
                        throw new Error(`Unable to parse JSON after all cleanup attempts: ${parseError.message}`);
                    }
                }
            } else if (typeof payloadData === 'object' && payloadData !== null) {
                // It's already an object (Salesforce Proxy object)
                rawPayload = payloadData;
                console.log('Payload is already an object, using directly');
            } else {
                throw new Error(`Unexpected payload data type: ${typeof payloadData}`);
            }

            // Validate that we have a valid object
            if (!rawPayload || typeof rawPayload !== 'object') {
                throw new Error('Parsed payload is not a valid object');
            }

            const dataCategories = {};

            // Automatically detect data types and structure
            Object.keys(rawPayload).forEach(key => {
                try {
                    const value = rawPayload[key];
                    // Process and clean the data for better compatibility with standard components
                    const processedData = this.processDataForStandardComponents(value);

                    dataCategories[key] = {
                        key: key,
                        type: Array.isArray(value) ? 'array' : typeof value,
                        data: processedData,
                        count: Array.isArray(value) ? value.length : null,
                        fields: this.extractFieldNames(value),
                        displayName: this.formatDisplayName(key),
                        originalValue: value // Keep original for debugging
                    };

                    console.log(`Processed data category '${key}':`, {
                        type: dataCategories[key].type,
                        count: dataCategories[key].count,
                        fieldsCount: dataCategories[key].fields.length
                    });
                } catch (categoryError) {
                    console.error(`Error processing category '${key}':`, categoryError);
                    // Don't let one bad category break everything - skip it
                }
            });

            this.parsedDataCategories = dataCategories; 
            if(this.meetingType === 'Adhoc'){
                this.filterParsedDataCategories(this.selectedDataCategories);
            };
            console.log('this.parsedDataCategories', JSON.stringify(this.parsedDataCategories));
            console.log('Final parsed data categories:', JSON.stringify(Object.keys(dataCategories)));

        } catch (error) {
            console.error('Error parsing payload data:', error);
            console.error('Original payload:', this.payloadJSON);

            // Set a meaningful error state that won't break the UI
            this.parsedDataCategories = {
                'Error': {
                    key: 'Error',
                    type: 'object',
                    data: { message: 'Failed to parse data', error: error.message },
                    count: null,
                    fields: ['message', 'error'],
                    displayName: 'Parsing Error'
                }
            };
        }
    }

    // Clean up common JSON formatting issues with enhanced error handling
    cleanupJSON(jsonString) {
        if (!jsonString || typeof jsonString !== 'string') {
            return jsonString;
        }

        try {
            // First, let's try parsing as-is to see if it's already valid
            JSON.parse(jsonString);
            return jsonString; // If it parses, return original
        } catch (e) {
            // If parsing fails, apply cleanup rules
            console.log('JSON parsing failed, applying cleanup rules:', e.message);
        }

        let cleaned = jsonString.trim();
        cleaned = cleaned
            .replace(/\n/g, '\\n')    // Escape newline characters
            .replace(/\r/g, '\\r')    // Escape carriage return characters
            .replace(/\t/g, '\\t')    // Escape tab characters
            .replace(/\f/g, '\\f')    // Escape form feed characters
            .replace(/\b/g, '\\b');   // Escape backspace characters
        // Step 1: Remove trailing commas before closing brackets and braces
        cleaned = cleaned.replace(/,(\s*[}\]])/g, '$1');

        // Step 2: Fix missing quotes around property names
        cleaned = cleaned.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');

        // Step 3: Fix comma-separated numbers first (before other processing)
        cleaned = cleaned.replace(/:(\s*)(\d+),(\d+)(\s*[,}\]])/g, ':$1$2$3$4');

        // Step 4: Handle unquoted values more intelligently
        cleaned = cleaned.replace(/:(\s*)([^",\[\]{}\s][^,\[\]{}]*?)(\s*[,}\]])/g, (match, space1, value, space2) => {
            const trimmedValue = value.trim();

            // Don't quote these types of values
            if (/^(true|false|null)$/i.test(trimmedValue)) {
                return `:${space1}${trimmedValue}${space2}`;
            }

            // Handle numbers (including negative, decimal, and scientific notation)
            if (/^-?\d+\.?\d*([eE][+-]?\d+)?$/.test(trimmedValue)) {
                return `:${space1}${trimmedValue}${space2}`;
            }

            // Handle currency values - keep as strings but ensure they're quoted
            if (/^\$[\d,]+\.?\d*$/.test(trimmedValue)) {
                return `:${space1}"${trimmedValue}"${space2}`;
            }

            // Handle percentage values
            if (/^\d+\.?\d*%$/.test(trimmedValue)) {
                return `:${space1}"${trimmedValue}"${space2}`;
            }

            // Quote everything else that isn't already quoted
            if (!trimmedValue.startsWith('"') || !trimmedValue.endsWith('"')) {
                // Escape any internal quotes first
                const escapedValue = trimmedValue.replace(/"/g, '\\"');
                return `:${space1}"${escapedValue}"${space2}`;
            }

            return match; // Return original if already quoted
        });

        // Step 5: Fix any double escaping issues
        cleaned = cleaned.replace(/\\"/g, '"').replace(/\\\\/g, '\\');

        // Step 6: Validate the cleaned JSON
        try {
            JSON.parse(cleaned);
            return cleaned;
        } catch (e) {
            console.error('JSON cleanup failed, returning original string:', e.message);
            console.error('Cleaned JSON that failed:', cleaned);
            return jsonString; // Return original if cleanup didn't work
        }
    }

    // Fallback parsing strategies for severely malformed JSON
    tryFallbackParsing(originalJson) {
        console.log('Attempting fallback parsing strategies...');

        const strategies = [
            // Strategy 1: Try to fix common Salesforce Flow issues
            () => {
                let fixed = originalJson
                    // Fix trailing commas in arrays and objects
                    .replace(/,\s*]/g, ']')
                    .replace(/,\s*}/g, '}')
                    // Fix comma-separated numbers (like "Balance":5,000 -> "Balance":5000)
                    .replace(/:\s*(\d+),(\d+)/g, ':$1$2')
                    // Fix unquoted numeric values by keeping them as numbers
                    .replace(/"Amount":\s*(\d+)/g, '"Amount":$1')
                    .replace(/"Balance":\s*(\d+)/g, '"Balance":$1')
                    .replace(/"Total [^"]*":\s*(\d+)/g, (match, num) => match.replace(num, num))
                    // Keep Revenue as number
                    .replace(/"Rolling 12 Month Revenue":\s*(\d+)/g, '"Rolling 12 Month Revenue":$1');

                return JSON.parse(fixed);
            },

            // Strategy 2: Use eval as last resort (with safety checks)
            () => {
                // Only try this if the JSON looks safe (no functions, no suspicious patterns)
                if (!/function|eval|\(|\)|script/i.test(originalJson)) {
                    console.warn('Attempting eval fallback - this should be avoided in production');
                    return eval('(' + originalJson + ')');
                }
                return null;
            },

            // Strategy 3: Manual key-value extraction for known patterns
            () => {
                console.log('Attempting manual extraction...');
                return this.manualJsonExtraction(originalJson);
            }
        ];

        for (let i = 0; i < strategies.length; i++) {
            try {
                const result = strategies[i]();
                if (result && typeof result === 'object') {
                    console.log(`Fallback strategy ${i + 1} succeeded`);
                    return result;
                }
            } catch (e) {
                console.log(`Fallback strategy ${i + 1} failed:`, e.message);
            }
        }

        console.error('All fallback parsing strategies failed');
        return null;
    }

    // Manual extraction for known JSON patterns (most reliable fallback)
    manualJsonExtraction(jsonString) {
        const result = {};

        // Extract arrays and objects using regex patterns specific to our expected data
        const patterns = {
            'Opportunities': /"Opportunities":\s*\[(.*?)\]/s,
            'Financial Summary': /"Financial Summary":\s*\{([^}]*)\}/,
            'Employment': /"Employment":\s*\[(.*?)\]/s,
            'Education': /"Education":\s*\[(.*?)\]/s,
            'Meaningful Interactions': /"Meaningful Interactions":\s*\[(.*?)\]/s,
            'ClientServiceInteractions': /"ClientServiceInteractions":\s*\[(.*?)\]/s
        };

        Object.entries(patterns).forEach(([key, pattern]) => {
            const match = jsonString.match(pattern);
            if (match) {
                try {
                    if (key === 'Financial Summary') {
                        // Parse object
                        const objContent = '{' + match[1] + '}';
                        result[key] = JSON.parse(objContent);
                    } else {
                        // Parse array
                        const arrayContent = '[' + match[1] + ']';
                        result[key] = JSON.parse(arrayContent);
                    }
                } catch (e) {
                    console.warn(`Failed to parse ${key} manually:`, e.message);
                    result[key] = key === 'Financial Summary' ? {} : [];
                }
            }
        });

        return Object.keys(result).length > 0 ? result : null;
    }

    // Process data to make it compatible with standard Lightning components
    processDataForStandardComponents(data) {
        if (Array.isArray(data)) {
            return data.map(item => this.processItemForStandardComponents(item));
        } else if (typeof data === 'object' && data !== null) {
            return this.processItemForStandardComponents(data);
        }
        return data;
    }

    // Process individual items to clean up data formatting
    processItemForStandardComponents(item) {
        if (typeof item !== 'object' || item === null) {
            return item;
        }

        const processedItem = {};
        Object.keys(item).forEach(key => {
            let value = item[key];

            // Handle date fields - convert readable date strings to Date objects
            if (this.isDateField(key, value)) {
                value = this.parseDate(value);
            }
            // Handle currency fields - ensure they're numbers (should already be fixed per user)
            else if (this.isCurrencyField(key, value)) {
                value = this.parseCurrency(value);
            }

            processedItem[key] = value;
        });

        return processedItem;
    }

    // Check if a field represents a date
    isDateField(fieldName, value) {
        const dateFieldNames = ['date', 'closedate', 'startdate', 'enddate', 'createddate', 'modifieddate'];
        const isDateFieldName = dateFieldNames.some(dateField =>
            fieldName.toLowerCase().includes(dateField)
        );

        // Also check if the value looks like a readable date string
        const isDateString = typeof value === 'string' &&
            /^[A-Za-z]+\s+\d{1,2},\s+\d{4}$/.test(value.trim()); // "November 23, 2022"

        return isDateFieldName || isDateString;
    }

    // Check if a field represents currency
    isCurrencyField(fieldName, value) {
        const currencyFieldNames = ['amount', 'balance', 'total', 'revenue', 'credit', 'deposit'];
        return currencyFieldNames.some(currencyField =>
            fieldName.toLowerCase().includes(currencyField)
        ) && (typeof value === 'string' && value.includes('$'));
    }

    // Parse date strings into Date objects
    parseDate(dateString) {
        if (!dateString || typeof dateString !== 'string') {
            return dateString;
        }

        try {
            // Handle "November 23, 2022" format
            const date = new Date(dateString);

            // Verify the date is valid
            if (isNaN(date.getTime())) {
                console.warn('Invalid date string:', dateString);
                return dateString; // Return original if parsing fails
            }

            return date;
        } catch (error) {
            console.warn('Error parsing date:', dateString, error);
            return dateString; // Return original if parsing fails
        }
    }

    // Parse currency strings into numbers
    parseCurrency(currencyString) {
        if (typeof currencyString === 'number') {
            return currencyString;
        }

        if (typeof currencyString === 'string') {
            // Remove currency symbols and commas, then parse
            const numStr = currencyString.replace(/[$,]/g, '');
            const num = parseFloat(numStr);
            return isNaN(num) ? 0 : num;
        }

        return 0;
    }

    // Extract field names from data for flexible rendering
    extractFieldNames(data) {
        if (Array.isArray(data) && data.length > 0) {
            // Get all unique field names from array items
            const allFields = new Set();
            data.forEach(item => {
                if (typeof item === 'object' && item !== null) {
                    Object.keys(item).forEach(field => allFields.add(field));
                }
            });
            return Array.from(allFields);
        }
        if (typeof data === 'object' && data !== null) {
            return Object.keys(data);
        }
        return [];
    }

    // Format key names for display (convert camelCase/PascalCase to readable format)
    formatDisplayName(key) {
        return key
            .replace(/([A-Z])/g, ' $1') // Add space before capital letters
            .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
            .trim();
    }

    // Initialize display configuration based on parsed data
    initializeDisplayConfig() {
        const cards = [];
        const accordions = [];

        try {
            // Default configuration mapping - this could be made configurable later
            Object.keys(this.parsedDataCategories).forEach(key => {
                const category = this.parsedDataCategories[key];

                // Decide whether to show as card or accordion based on data characteristics
                if (this.shouldShowAsCard(category)) {
                    cards.push(this.createCardConfig(category));
                }

                // Most data can also be shown as accordion (detailed view)
                if (this.shouldShowAsAccordion(category)) {
                    accordions.push(this.createAccordionConfig(category));
                }
            });

            this.displayConfig = { cards, accordions };
        } catch (error) {
            console.error('Error initializing display config:', error);
            // Ensure we have a valid displayConfig even on error
            this.displayConfig = { cards: [], accordions: [] };
        }
    }

     filterParsedDataCategories(selectedDataCategories) {
            Object.keys(this.parsedDataCategories).forEach(key => {
                console.log('parsedDataCategories-key', key);
                console.log('parsedDataCategoryValues:', JSON.stringify(this.parsedDataCategories[key]));
            if (!selectedDataCategories.includes(key)){
            delete this.parsedDataCategories[key];
            }
        });
        }

    // Determine if data should be displayed as a card
    shouldShowAsCard(category) {
        // Show as card if:
        // 1. It's a financial summary (object with numeric values)
        // 2. It's a small array (< 6 items) with important data - BUT NOT Opportunities (they get datatable)
        // 3. It's a single important metric

        if (category.type === 'object' && category.key.toLowerCase().includes('financial')) {
            return true;
        }

        // Skip opportunities for cards since they now use datatable
        if (category.key === 'Opportunities') {
            return false;
        }

        if (category.type === 'array' && category.count > 0 && category.count <= 5) {
            return ['Recent Activities', 'Tasks'].includes(category.key);
        }

        return false;
    }

    // Determine if data should be displayed as an accordion
    shouldShowAsAccordion(category) {
        // Show as accordion if:
        // 1. It's an array with items (including Opportunities which will use datatable inside accordion)
        // 2. It's an object with multiple properties
        // 3. It's detailed data that takes up space

        return (category.type === 'array' && category.count > 0) ||
               (category.type === 'object' && category.fields.length > 0);
    }

    // Create card configuration
    createCardConfig(category) {
        return {
            key: category.key,
            displayName: category.displayName,
            type: category.type,
            data: category.data,
            count: category.count,
            icon: this.getIconForCategory(category.key),
            priority: this.getPriorityForCategory(category.key)
        };
    }

    // Create accordion configuration
    createAccordionConfig(category) {
        return {
            key: category.key,
            displayName: category.displayName,
            type: category.type,
            data: category.data,
            count: category.count,
            fields: category.fields,
            icon: this.getIconForCategory(category.key),
            priority: this.getPriorityForCategory(category.key),
            recordType: this.getRecordTypeForCategory(category.key),
            useDataTable: category.key === 'Opportunities' // Flag to use datatable instead of list
        };
    }

    // Get appropriate icon for data category
    getIconForCategory(key) {
        const iconMap = {
            'Financial Summary': 'utility:money',
            'Opportunities': 'standard:opportunity',
            'Employment': 'utility:work',
            'Education': 'utility:education',
            'Meaningful Interactions': 'utility:comments',
            'ClientServiceInteractions': 'utility:customer_service',
            'Previous Interactions': 'utility:comments'
        };

        return iconMap[key] || 'utility:list';
    }

    // Get priority for sorting (lower number = higher priority)
    getPriorityForCategory(key) {
        const priorityMap = {
            'Financial Summary': 1,
            'Opportunities': 2,
            'Employment': 3,
            'Education': 4,
            'Meaningful Interactions': 5,
            'ClientServiceInteractions': 6
        };

        return priorityMap[key] || 10;
    }

    // Get record type for linking
    getRecordTypeForCategory(key) {
        const recordTypeMap = {
            'Opportunities': 'Opportunity',
            'Employment': 'Contact', // or custom object
            'Education': 'Contact', // or custom object
            'Meaningful Interactions': 'Task',
            'ClientServiceInteractions': 'Case'
        };

        return recordTypeMap[key] || null;
    }


    // Computed properties for sorted display items
    get sortedCards() {
        if (!this.displayConfig.cards) return [];
        return [...this.displayConfig.cards].sort((a, b) => a.priority - b.priority);
    }

    get sortedAccordions() {
        if (!this.displayConfig.accordions) return [];
        return [...this.displayConfig.accordions].sort((a, b) => a.priority - b.priority);
    }

    get hasCards() {
        return this.sortedCards.length > 0;
    }

    get hasAccordions() {
        return this.sortedAccordions.length > 0;
    }

    // Add debug computed properties to help troubleshoot
    get dataLoadingState() {
        return {
            isLoadingData: this.isLoadingData,
            isLoadingSummary: this.isLoadingSummary,
            hasCards: this.hasCards,
            hasAccordions: this.hasAccordions,
            cardsCount: this.sortedCards.length,
            accordionsCount: this.sortedAccordions.length
        };
    }



    // Handle record click events from child components
    handleRecordClick(event) {
        const { recordId, recordType } = event.detail;

        if (recordId && recordId.length >= 15) {
            try {
                this.modalRecordId = recordId;
                this.modalObjectApiName = this.getObjectApiName(recordType);
                this.showModal = true;
            } catch (error) {
                console.error('Error opening modal from dynamic component:', error);
            }
        }
    }

    // Map record types from our links to proper Object API Names for lightning-record-form
    getObjectApiName(recordType) {
        const objectMapping = {
            'Account': 'Account',
            'Contact': 'Contact',
            'Opportunity': 'Opportunity',
            'Case': 'Case',
            'Lead': 'Lead',
            'Task': 'Task',
            'Event': 'Event',
            'Campaign': 'Campaign',
            'Product2': 'Product2',
            'Employment':'UST_Employment__c',
            // Add more mappings as needed for custom objects
        };

        return objectMapping[recordType] || recordType;
    }

    renderedCallback() {
        // Render the summary content manually to preserve all HTML attributes
        if (this.summaryText && !this.summaryRendered) {
            const summaryContainer = this.template.querySelector('.summary-content');
            if (summaryContainer) {
                // Set the HTML content directly
                console.log("summary text"+JSON.stringify(this.summaryText));
                summaryContainer.innerHTML = this.summaryText;

                // Apply SLDS styling classes to HTML formatting elements
                this.applySLDSStylestoSummary(summaryContainer);

                // Add event listeners to all record links
                const recordLinks = summaryContainer.querySelectorAll('a[data-record-id]');
                console.log("recordLinks"+JSON.stringify(recordLinks));
                recordLinks.forEach(link => {
                    // Remove any existing listeners to prevent duplicates
                    link.removeEventListener('click', this.boundHandleLinkClick);

                    // Add click event listener
                    this.boundHandleLinkClick = this.handleDirectLinkClick.bind(this);
                    link.addEventListener('click', this.boundHandleLinkClick);

                    // Add keyboard event listener for accessibility
                    link.removeEventListener('keydown', this.boundHandleLinkKeydown);
                    this.boundHandleLinkKeydown = this.handleDirectLinkKeydown.bind(this);
                    link.addEventListener('keydown', this.boundHandleLinkKeydown);
                });
                 console.log("UpdatedrecordLinks"+JSON.stringify(recordLinks));
                this.summaryRendered = true;
            }
        }
    }

    // Apply SLDS styling classes to HTML elements in the summary
    applySLDSStylestoSummary(container) {
        if (!container) return;

        // Style headings
        container.querySelectorAll('h1').forEach(el => {
            el.className = 'slds-text-heading_large slds-m-bottom_small slds-text-color_default';
        });

        container.querySelectorAll('h2').forEach(el => {
            el.className = 'slds-text-heading_medium slds-m-bottom_small slds-text-color_default';
        });

        container.querySelectorAll('h3').forEach(el => {
            el.className = 'slds-text-heading_small slds-m-bottom_x-small slds-text-color_default';
        });

        container.querySelectorAll('h4').forEach(el => {
            el.className = 'slds-text-body_regular slds-text-font_monospace slds-m-bottom_x-small slds-text-color_default';
        });

        // Style lists
        container.querySelectorAll('ul').forEach(el => {
            el.className = 'slds-list_dotted slds-m-bottom_medium slds-m-left_large';
        });

        container.querySelectorAll('ol').forEach(el => {
            el.className = 'slds-list_ordered slds-m-bottom_medium slds-m-left_large';
        });

        // Style list items
        container.querySelectorAll('li').forEach(el => {
            el.className = 'slds-item slds-m-bottom_x-small';
        });

        // Style paragraphs
        container.querySelectorAll('p').forEach(el => {
            el.className = 'slds-text-body_regular slds-m-bottom_small';
        });

        // Style strong/bold text
        container.querySelectorAll('strong, b').forEach(el => {
            el.className = 'slds-text-font_monospace';
        });

        // Style emphasis/italic text
        container.querySelectorAll('em, i').forEach(el => {
            el.className = 'slds-text-font_monospace';
        });
    }

    disconnectedCallback() {
        // Clean up event listeners to prevent memory leaks
        const summaryContainer = this.template.querySelector('.summary-content');
        if (summaryContainer) {
            const recordLinks = summaryContainer.querySelectorAll('a[data-record-id]');
            recordLinks.forEach(link => {
                link.removeEventListener('click', this.boundHandleLinkClick);
                link.removeEventListener('keydown', this.boundHandleLinkKeydown);
            });
        }
    }

    // Handle direct clicks on record links (bound to individual link elements)
    handleDirectLinkClick(event) {
        // Prevent default anchor behavior
        event.preventDefault();
        event.stopPropagation();

        const link = event.currentTarget; // Use currentTarget since we bound to the specific link
        const recordId = link.dataset.recordId;
        const recordType = link.dataset.recordType;
        console.log('recordType', recordType);
        this.modalObjectApiName = this.getObjectApiName(recordType);
        console.log('this.modalObjectApiName'+this.modalObjectApiName);
        if (recordId && recordId.length >= 15) {
            try {
                this.modalRecordId = recordId;
                this.modalObjectApiName = this.getObjectApiName(recordType);
                this.showModal = true;
            } catch (error) {
                console.error('Error opening modal:', error);
            }
        }
    }

    // Handle keyboard events for accessibility (Enter and Space keys)
    handleDirectLinkKeydown(event) {
        // Check if Enter or Space key was pressed
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleDirectLinkClick(event);
        }
    }

    // Handle closing the record details modal
    handleCloseModal() {
        this.showModal = false;
        this.modalRecordId = '';
        this.modalObjectApiName = '';
        this.modalError = '';
    }

    // Handle successful record form load
    handleRecordFormLoad(event) {
        this.modalError = '';
    }

    // Handle record form error
    handleRecordFormError(event) {
        console.error('Record form error:', event.detail);
        this.modalError = event.detail.message || 'Unknown error loading record';
    }
}