import { LightningElement, api, wire, track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

export default class UST_Agentforce_Meeting_Prep_Component extends LightningElement {
    @api recordId;

    @track meetingType = '';
    @track meetingTitle = '';
    @track meetingPurpose = '';
    @track selectedDataCategories = [];
    @track showMeetingPrep = false;
    @track fallbackRecordId;

    @wire(CurrentPageReference)
    setCurrentPageReference(currentPageReference) {
        if (!this.recordId && currentPageReference && currentPageReference.attributes && currentPageReference.attributes.recordId) {
            this.fallbackRecordId = currentPageReference.attributes.recordId;
        }
    }

    get effectiveRecordId() {
        return this.recordId || this.fallbackRecordId;
    }

    // Options for combobox
    meetingTypeOptions = [
        { label: 'Quarterly', value: 'Quarterly' },
        { label: 'Adhoc', value: 'Adhoc' }
    ];

    // Data categories for Adhoc
    dataCategoryOptions = [
        { label: 'Financial Summary', value: 'FinancialSummary', selected: true },
        { label: 'Meaningful Interactions', value: 'MeaningfulInteractions', selected: true },
        { label: 'Client Service Interactions', value: 'ClientServiceInteractions', selected: true },
        { label: 'Opportunities', value: 'Opportunities', selected: true },
        { label: 'Recently Opened Accounts', value: 'RecentlyOpenedAccounts', selected: false },
        { label: 'Upcoming Tasks', value: 'UpcomingTasks', selected: false },
        { label: 'Overdue Tasks', value: 'OverdueTasks', selected: false },
        { label: 'Curated Events', value: 'CuratedEvents', selected: false },
        { label: 'Preferred Rewards', value: 'PreferredRewards', selected: false },
        { label: 'Life Events', value: 'LifeEvents', selected: false },
        { label: 'Employment', value: 'Employment', selected: false },
        { label: 'Education', value: 'Education', selected: false }
    ];

    preselectedLabels = [
        'Financial Summary',
        'Meaningful Interactions',
        'Client Service Interactions',
        'Opportunities'
    ];

    connectedCallback() {
        this.updateSelectedCategories();
    }

    get isAdhoc() {
        return this.meetingType === 'Adhoc';
    }

    handleMeetingTypeChange(event) {
        this.meetingType = event.detail.value;
        // Reset on meeting type switch
        if (!this.isAdhoc) {
            this.meetingPurpose = '';
            this.selectedDataCategories = [];
            this.updateSelectedCategories(true); // reset to default selection
        } else {
            this.updateSelectedCategories();
        }
    }

    handleMeetingTitleChange(event) {
        this.meetingTitle = event.detail.value;
    }

    handleMeetingPurposeChange(event) {
        this.meetingPurpose = event.detail.value;
    }

    handleDataCategoryChange(event) {
        const categoryValue = event.target.value;
        const isChecked = event.target.checked;
        this.dataCategoryOptions = this.dataCategoryOptions.map(option => {
            if (option.value === categoryValue) {
                return { ...option, selected: isChecked };
            }
            return option;
        });
        this.updateSelectedCategories();
    }

    updateSelectedCategories(reset = false) {
        if (reset) {
            // For Quarterly, deselect all by default
            this.dataCategoryOptions = this.dataCategoryOptions.map(o => ({ ...o, selected: this.preselectedLabels.includes(o.label) }));
        }
        this.selectedDataCategories = this.dataCategoryOptions
            .filter(option => option.selected)
            .map(option => option.value);
            console.log(JSON.stringify(this.selectedDataCategories));
    }

    get isSaveDisabled() {
    // Always require meeting type and title
    if (!this.meetingType) {
        return true;
    }

    if (this.isAdhoc) {
        // For Adhoc, require at least one category and purpose
        const hasCheckbox = this.selectedDataCategories.length > 0;
        if (!hasCheckbox) {
            return true;
        }
    }

    return false;
}

    handleSave() {
        this.showMeetingPrep = true;
    }

    handleRefresh(){
        this.showMeetingPrep = false;
        this.meetingType = '';
        this.meetingPurpose = '';
        this.meetingTitle = '';
        this.updateSelectedCategories(true);
    }

    handleSummaryLoaded() {
        // child handles its own loading
    }
}