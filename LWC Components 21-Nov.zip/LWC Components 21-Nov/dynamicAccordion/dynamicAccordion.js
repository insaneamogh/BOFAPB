import { LightningElement, api, track } from 'lwc';

export default class DynamicAccordion extends LightningElement {
    @api accordionConfig = {};
    @track isExpanded = false;
    @track processedItems = [];

    connectedCallback() {
        this.processAccordionData();
    }

    // Process accordion data based on configuration
    processAccordionData() {
        if (!this.accordionConfig || !this.accordionConfig.data) {
            return;
        }

        const { data, type } = this.accordionConfig;

        if (type === 'array') {
            this.processedItems = this.formatArrayItems(data);
        } else if (type === 'object') {
            this.processedItems = this.formatObjectItems(data);
        }
    }

    // Format array data as list items
    formatArrayItems(data) {
        return data.map((item, index) => {
            const formattedItem = {
                id: item.Id || `item-${index}`,
                recordId: item.Id || null,
                fields: []
            };

            // Process each field in the item
            Object.keys(item).forEach(fieldName => {
                console.log('valuefieldName'+fieldName);
                console.log('item[fieldName]'+item[fieldName]);
                if (fieldName !== 'Id') { // Skip Id field as it's used for recordId
                    formattedItem.fields.push({
                        id: `${formattedItem.id}-${fieldName}`,
                        name: fieldName,
                        label: this.formatFieldLabel(fieldName),
                        value: this.formatFieldValue(fieldName, item[fieldName]),
                        isClickable: fieldName === 'Id' || this.isRecordField(fieldName)
                    });
                }
            });

            return formattedItem;
        });
    }

    // Format object data as key-value pairs
    formatObjectItems(data) {
        const item = {
            id: 'object-data',
            recordId: null,
            fields: []
        };

        Object.keys(data).forEach(fieldName => {
            item.fields.push({
                id: `object-${fieldName}`,
                name: fieldName,
                label: this.formatFieldLabel(fieldName),
                value: this.formatFieldValue(fieldName, data[fieldName]),
                isClickable: false
            });
        });

        return [item];
    }

    // Format field labels for display
    formatFieldLabel(fieldName) {
        return fieldName
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, str => str.toUpperCase())
            .trim();
    }

    // Format field values based on type and content
    formatFieldValue(fieldName, value) {
        if (value === null || value === undefined || value === '') {
            return '—'; // Em dash for empty values
        }

        // Handle currency values
        if (typeof value === 'string' && value.includes('$')) {
            return value;
        }

        // Handle numeric values for amount/money fields
        if (typeof value === 'number' && fieldName.toLowerCase().includes('amount')) {
            return this.formatCurrency(value);
        }

        // Handle dates
        if (fieldName.toLowerCase().includes('date')) {
            return this.formatDate(value);
        }

        // Handle IDs (show truncated version)
        if (fieldName.toLowerCase().includes('id') && typeof value === 'string' && value.length > 15) {
            return `${value.substring(0, 8)}...`;
        }

        return String(value);
    }

    // Check if field represents a record that should be clickable
    isRecordField(fieldName) {
        const recordFields = ['id', 'recordid', 'accountid', 'contactid', 'opportunityid'];
        return recordFields.includes(fieldName.toLowerCase());
    }

    // Format currency values
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    // Format dates
    formatDate(dateValue) {
        if (!dateValue) return '';
        try {
            const date = new Date(dateValue);
            return date.toLocaleDateString();
        } catch (error) {
            return String(dateValue);
        }
    }

    // Handle accordion expansion/collapse
    handleToggle() {
        this.isExpanded = !this.isExpanded;
    }

    // Handle field click for record navigation
    handleFieldClick(event) {
        const fieldId = event.currentTarget.dataset.fieldId;
        const recordId = event.currentTarget.dataset.recordId;

        if (recordId && recordId.length >= 15) {
            // Dispatch event to parent component for record navigation
            this.dispatchEvent(new CustomEvent('recordclick', {
                detail: {
                    recordId: recordId,
                    recordType: this.accordionConfig.recordType
                },
                bubbles: true,
                composed: true
            }));
        }
    }

    // Handle datatable row actions
    handleDataTableRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;

        if (actionName === 'view_details' && row.Id) {
            // Dispatch event to parent component for record navigation
            this.dispatchEvent(new CustomEvent('recordclick', {
                detail: {
                    recordId: row.Id,
                    recordType: this.accordionConfig.recordType || 'Opportunity'
                },
                bubbles: true,
                composed: true
            }));
        }
    }

    // Getters for template
    get sectionTitle() {
        return this.accordionConfig.displayName || this.accordionConfig.key || 'Data';
    }

    get sectionIcon() {
        return this.accordionConfig.icon || 'utility:list';
    }

    get itemCount() {
        if (this.shouldUseDataTable && this.accordionConfig.data) {
            return this.accordionConfig.data.length;
        }
        return this.processedItems ? this.processedItems.length : 0;
    }

    get hasItems() {
        return this.itemCount > 0;
    }

    get expandIcon() {
        return this.isExpanded ? 'utility:chevrondown' : 'utility:chevronright';
    }

    get sectionClass() {
        return `slds-section ${this.isExpanded ? 'slds-is-open' : ''}`;
    }

    get contentClass() {
        return `slds-section__content ${this.isExpanded ? '' : 'slds-hide'}`;
    }

    // Determine if should use datatable instead of list
    get shouldUseDataTable() {
        return this.accordionConfig && this.accordionConfig.useDataTable === true;
    }

    get financialSummaryCheck() {
        if (this.accordionConfig.key === 'FinancialSummary') {
             return true;
        }
    }

    // Column definitions for datatable (currently supports Opportunities)
    get datatableColumns() {
        if (this.accordionConfig.key === 'Opportunities') {
            return [
                {
                    label: 'Opportunity Name',
                    fieldName: 'Name',
                    type: 'text',
                    sortable: true,
                    wrapText: true
                },
                {
                    label: 'Amount',
                    fieldName: 'Amount',
                    type: 'currency',
                    sortable: true,
                    typeAttributes: {
                        currencyCode: 'USD',
                        currencyDisplayAs: 'symbol'
                    }
                },
                {
                    label: 'Stage',
                    fieldName: 'Stage',
                    type: 'text',
                    sortable: true
                },
                {
                    label: 'Close Date',
                    fieldName: 'CloseDate',
                    type: 'date',
                    sortable: true,
                    typeAttributes: {
                        year: 'numeric',
                        month: 'short',
                        day: '2-digit'
                    }
                },
                {
                    type: 'action',
                    typeAttributes: {
                        rowActions: [
                            { label: 'View Details', name: 'view_details' }
                        ]
                    }
                }
            ];
        }
        // Future: Add column definitions for other data types
        return [];
    }
}