import { LightningElement, api, track } from 'lwc';

export default class DynamicAccordion extends LightningElement {
    @api accordionConfig = {};
    @track isExpanded = false;
    @track processedItems = [];

    connectedCallback() {
        this.processAccordionData();
    }

    // Process accordion data based on configuration
    processAccordionData() {
        if (!this.accordionConfig || !this.accordionConfig.data) {
            return;
        }

        const { data, type } = this.accordionConfig;

        if (type === 'array') {
            this.processedItems = this.formatArrayItems(data);
        } else if (type === 'object') {
            this.processedItems = this.formatObjectItems(data);
        }
    }

    // Format array data as list items
    formatArrayItems(data) {
        return data.map((item, index) => {
            const formattedItem = {
                id: item.Id || `item-${index}`,
                recordId: item.Id || null,
                fields: []
            };

            // Process each field in the item
            Object.keys(item).forEach(fieldName => {
                console.log('valuefieldName'+fieldName);
                console.log('item[fieldName]'+item[fieldName]);
                if (fieldName !== 'Id') { // Skip Id field as it's used for recordId
                    formattedItem.fields.push({
                        id: `${formattedItem.id}-${fieldName}`,
                        name: fieldName,
                        label: this.formatFieldLabel(fieldName),
                        value: this.formatFieldValue(fieldName, item[fieldName]),
                        isClickable: fieldName === 'Id' || this.isRecordField(fieldName)
                    });
                }
            });

            return formattedItem;
        });
    }

    // Format object data as key-value pairs
    formatObjectItems(data) {
        const item = {
            id: 'object-data',
            recordId: null,
            fields: []
        };

        Object.keys(data).forEach(fieldName => {
            item.fields.push({
                id: `object-${fieldName}`,
                name: fieldName,
                label: this.formatFieldLabel(fieldName),
                value: this.formatFieldValue(fieldName, data[fieldName]),
                isClickable: false
            });
        });

        return [item];
    }

    // Format field labels for display
    formatFieldLabel(fieldName) {
        return fieldName
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, str => str.toUpperCase())
            .trim();
    }

    // Format field values based on type and content
    formatFieldValue(fieldName, value) {
        if (value === null || value === undefined || value === '') {
            return '—'; // Em dash for empty values
        }

        // Handle currency values
        if (typeof value === 'string' && value.includes('$')) {
            return value;
        }

        // Handle numeric values for amount/money fields
        if (typeof value === 'number' && fieldName.toLowerCase().includes('amount')) {
            return this.formatCurrency(value);
        }

        // Handle dates
        if (fieldName.toLowerCase().includes('date')) {
            return this.formatDate(value);
        }

        // Handle IDs (show truncated version)
        if (fieldName.toLowerCase().includes('id') && typeof value === 'string' && value.length > 15) {
            return `${value.substring(0, 8)}...`;
        }

        return String(value);
    }

    // Check if field represents a record that should be clickable
    isRecordField(fieldName) {
        const recordFields = ['id', 'recordid', 'accountid', 'contactid', 'opportunityid'];
        return recordFields.includes(fieldName.toLowerCase());
    }

    // Format currency values
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    // Format dates
    formatDate(dateValue) {
        if (!dateValue) return '';
        try {
            const date = new Date(dateValue);
            return date.toLocaleDateString();
        } catch (error) {
            return String(dateValue);
        }
    }

    // Handle accordion expansion/collapse
    handleToggle() {
        this.isExpanded = !this.isExpanded;
    }

    // Handle field click for record navigation
    handleFieldClick(event) {
        const fieldId = event.currentTarget.dataset.fieldId;
        const recordId = event.currentTarget.dataset.recordId;

        if (recordId && recordId.length >= 15) {
            // Dispatch event to parent component for record navigation
            this.dispatchEvent(new CustomEvent('recordclick', {
                detail: {
                    recordId: recordId,
                    recordType: this.accordionConfig.recordType
                },
                bubbles: true,
                composed: true
            }));
        }
    }

    // Handle datatable row actions
    handleDataTableRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;

        if (actionName === 'view_details' && row.Id) {
            console.log('this.accordionConfig.key'+this.accordionConfig.key);
             console.log('this.accordionConfig.recordType'+this.accordionConfig.recordType);
            // Dispatch event to parent component for record navigation
            this.dispatchEvent(new CustomEvent('recordclick', {
                detail: {
                    recordId: row.Id,
                    recordType: this.accordionConfig.recordType || this.accordionConfig.key
                },
                bubbles: true,
                composed: true
            }));
        }
    }

    // Getters for template
    get sectionTitle() {
        return this.accordionConfig.displayName || this.accordionConfig.key || 'Data';
    }

    get sectionIcon() {
        return this.accordionConfig.icon || 'utility:list';
    }

    get itemCount() {
        if (this.shouldUseDataTable && this.tableData) {
            return this.tableData.length;
        }
        return this.processedItems ? this.processedItems.length : 0;
    }

    get hasItems() {
        return this.itemCount > 0;
    }

    get expandIcon() {
        return this.isExpanded ? 'utility:chevrondown' : 'utility:chevronright';
    }

    get sectionClass() {
        return `slds-section ${this.isExpanded ? 'slds-is-open' : ''}`;
    }

    get contentClass() {
        return `slds-section__content ${this.isExpanded ? '' : 'slds-hide'}`;
    }

    // Determine if should use datatable instead of list
    get shouldUseDataTable() {
        return true;
      //  return this.accordionConfig && this.accordionConfig.useDataTable === true;
    }

    // Convert PreferredRewards object data to array format for datatable
    get tableData() {
        if (this.accordionConfig.key === 'PreferredRewards' && this.accordionConfig.type === 'object') {
            const data = this.accordionConfig.data;
            return [{
                Id: data.Id || 'preferred-rewards-1',
                field: data['Enrollment Code'] || '—',
                status: data['Reward Status'] || '—',
                balance: data['Reward 3 month Average Balance'] || '—',
                anniversary: data['Anniversary Date'] || '—'
            }];
        }
        // For all other cases, use the original data
        return this.accordionConfig.data;
    }

    get financialSummaryCheck() {
        if (this.accordionConfig.key === 'FinancialSummary') {
             return true;
        }
    }

    // Column definitions for datatable (currently supports Opportunities)
   /* get datatableColumns() {
        if (this.accordionConfig.key === 'Opportunities') {
            return [
                {
                    label: 'Opportunity Name',
                    fieldName: 'Name',
                    type: 'text',
                    sortable: true,
                    wrapText: true
                },
                {
                    label: 'Amount',
                    fieldName: 'Amount',
                    type: 'currency',
                    sortable: true,
                    typeAttributes: {
                        currencyCode: 'USD',
                        currencyDisplayAs: 'symbol'
                    }
                },
                {
                    label: 'Stage',
                    fieldName: 'Stage',
                    type: 'text',
                    sortable: true
                },
                {
                    label: 'Close Date',
                    fieldName: 'CloseDate',
                    type: 'date',
                    sortable: true,
                    typeAttributes: {
                        year: 'numeric',
                        month: 'short',
                        day: '2-digit'
                    }
                },
                {
                    type: 'action',
                    typeAttributes: {
                        rowActions: [
                            { label: 'View Details', name: 'view_details' }
                        ]
                    }
                }
            ];
        }
        // Future: Add column definitions for other data types
        return [];
    }*/

    get datatableColumns() {
    // if you want to control columns exactly per section:
    switch (this.accordionConfig.key) {
        case 'Opportunities':
            return [
                { label: 'Opportunity Name', fieldName: 'Name', type: 'text', sortable: true, wrapText: true },
                { label: 'Amount', fieldName: 'Amount', type: 'currency', sortable: true, typeAttributes: { currencyCode: 'USD', currencyDisplayAs: 'symbol' } },
                { label: 'Stage', fieldName: 'Stage', type: 'text', sortable: true },
                { label: 'Close Date', fieldName: 'CloseDate', type: 'date', sortable: true, typeAttributes: { year: 'numeric', month: 'short', day: '2-digit' } },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'Education':
            return [
                { label: 'School', fieldName: 'School', type: 'text' },
                { label: 'Degree', fieldName: 'Degree', type: 'text' },
                { label: 'Date', fieldName: 'Date', type: 'date' },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'Employment':
            return [
                { label: 'Affiliation', fieldName: 'Affiliation', type: 'text' },
                { label: 'Company', fieldName: 'Company', type: 'text' },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'MeaningfulInteractions':
        case 'ClientServiceInteractions':
            return [
                { label: 'Subject', fieldName: 'Subject', type: 'text' },
                { label: 'Description', fieldName: 'Description', type: 'text' },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'RecentlyOpenedAccounts':
            return [
                { label: 'Primary Owner', fieldName: 'Primary Owner', type: 'text' },
                { label: 'Seg', fieldName: 'Seg', type: 'boolean' },
                { label: 'Balance', fieldName: 'Balance', type: 'currency', typeAttributes: { currencyCode: 'USD', currencyDisplayAs: 'symbol' } },
                { label: 'Product Category', fieldName: 'Product Category', type: 'text' },
                { label: 'Opened Date', fieldName: 'OpenedDate', type: 'date' },
                { label: 'Rolling 12 Month Revenue', fieldName: 'Rolling 12 Month Revenue', type: 'currency', typeAttributes: { currencyCode: 'USD', currencyDisplayAs: 'symbol' } },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'UpcomingTasks':
        case 'OverdueTasks':
            return [
                { label: 'Subject', fieldName: 'Subject', type: 'text' },
                { label: 'Status', fieldName: 'Status', type: 'text' },
                // add more fields if needed
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'LifeEvents':
            return [
                { label: 'Life Event Name', fieldName: 'Life Event Name', type: 'text' },
                { label: 'Description', fieldName: 'Description', type: 'text' },
                { label: 'Life Event Date', fieldName: 'Life Event Date', type: 'date' },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'CuratedEvents':
            return [
                { label: 'Campaign Name', fieldName: 'Campaign Name', type: 'text' },
                { label: 'Campaign Start Date', fieldName: 'Campaign Start Date', type: 'date' },
                { label: 'RSVP', fieldName: 'RSVP', type: 'text' },
                { label: 'Attended', fieldName: 'Attended', type: 'boolean' },
                { label: 'Party Name', fieldName: 'Party Name', type: 'text' },
                { type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } }
            ];
        case 'PreferredRewards':
            return [
                { label: 'Enrollment', fieldName: 'field', type: 'text' },
                { label: 'Status', fieldName: 'status', type: 'text' },
                { label: '3 Month Average Balance', fieldName: 'balance', type: 'text' },
                { label: 'Anniversary', fieldName: 'anniversary', type: 'text' }
            ];
        default:
            // Fallback: Build columns from data fields
            if (Array.isArray(this.accordionConfig.data) && this.accordionConfig.data.length > 0) {
                const fields = Object.keys(this.accordionConfig.data[0])
                    .filter(key => key !== 'Id')
                    .map(field => ({
                        label: this.formatFieldLabel(field),
                        fieldName: field,
                        type: 'text'
                    }));
                fields.push({ type: 'action', typeAttributes: { rowActions: [{ label: 'View Details', name: 'view_details' }] } });
                return fields;
            }
            return [];
    }
}
}