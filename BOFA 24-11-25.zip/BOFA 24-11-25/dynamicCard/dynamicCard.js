import { LightningElement, api, track } from 'lwc';

export default class DynamicCard extends LightningElement {
    @api cardConfig = {};
    @track formattedData = [];

    connectedCallback() {
        this.processCardData();
    }

    // Process the card data based on configuration
    processCardData() {
        if (!this.cardConfig || !this.cardConfig.data) {
            return;
        }

        const { data, type, key } = this.cardConfig;

        if (type === 'error') {
            // Handle error data
            this.formattedData = this.formatErrorData(data);
        } else if (type === 'object') {
            // Handle object data (like Financial Summary)
            this.formattedData = this.formatObjectData(data);
        } else if (type === 'array') {
            // Handle array data (like recent opportunities)
            this.formattedData = this.formatArrayData(data, key);
        }
    }

    // Format error data for display
    formatErrorData(data) {
        const formatted = [];

        if (data.error) {
            formatted.push({
                id: 'error',
                label: 'Error Details',
                value: data.error,
                type: 'error'
            });
        }

        if (data.message) {
            formatted.push({
                id: 'message',
                label: 'Message',
                value: data.message,
                type: 'message'
            });
        }

        return formatted;
    }

    // Format object data as key-value pairs
    formatObjectData(data) {
        return Object.keys(data).map(key => ({
            id: key,
            label: this.formatFieldLabel(key),
            value: this.formatFieldValue(key, data[key]),
            type: 'metric'
        }));
    }

    // Format array data as summary information
    formatArrayData(data, categoryKey) {
        const formatted = [];

        // Add count summary
        formatted.push({
            id: 'count',
            label: 'Total Count',
            value: data.length.toString(),
            type: 'count'
        });

        // Add category-specific summaries
        if (categoryKey === 'Opportunities') {
            const totalValue = data.reduce((sum, opp) => {
                const amount = this.parseAmount(opp.Amount);
                return sum + amount;
            }, 0);

            formatted.push({
                id: 'total-value',
                label: 'Total Value',
                value: this.formatCurrency(totalValue),
                type: 'currency'
            });

            // Count by stage
            const stages = {};
            data.forEach(opp => {
                const stage = opp.Stage || 'Unknown';
                stages[stage] = (stages[stage] || 0) + 1;
            });

            Object.keys(stages).forEach(stage => {
                formatted.push({
                    id: `stage-${stage.toLowerCase().replace(/\s+/g, '-')}`,
                    label: stage,
                    value: stages[stage].toString(),
                    type: 'stage-count'
                });
            });
        }

        return formatted;
    }

    // Format field labels for display
    formatFieldLabel(key) {
        return key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, str => str.toUpperCase())
            .trim();
    }

    // Format field values based on type
    formatFieldValue(key, value) {
        // Handle currency values
        if (typeof value === 'string' && value.includes('$')) {
            return value;
        }

        // Handle numeric values for financial fields
        if (typeof value === 'number' && key.toLowerCase().includes('total')) {
            return this.formatCurrency(value);
        }

        // Handle dates
        if (key.toLowerCase().includes('date')) {
            return this.formatDate(value);
        }

        return String(value);
    }

    // Parse amount from string or number
    parseAmount(amount) {
        if (typeof amount === 'number') {
            return amount;
        }
        if (typeof amount === 'string') {
            // Remove currency symbols and parse
            const numStr = amount.replace(/[$,]/g, '');
            const num = parseFloat(numStr);
            return isNaN(num) ? 0 : num;
        }
        return 0;
    }

    // Format currency values
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }

    // Format dates
    formatDate(dateValue) {
        if (!dateValue) return '';
        try {
            const date = new Date(dateValue);
            return date.toLocaleDateString();
        } catch (error) {
            return String(dateValue);
        }
    }

    // Getters for template
    get cardTitle() {
        return this.cardConfig.displayName || this.cardConfig.key || 'Data';
    }

    get cardIcon() {
        return this.cardConfig.icon || 'utility:list';
    }

    get hasData() {
        return this.formattedData && this.formattedData.length > 0;
    }

    get cardCount() {
        if (this.cardConfig.type === 'array') {
            return this.cardConfig.count;
        }
        return null;
    }

    get showCount() {
        return this.cardCount !== null && this.cardCount !== undefined;
    }

    get isErrorCard() {
        return this.cardConfig && this.cardConfig.type === 'error';
    }

    get cardClass() {
        return this.isErrorCard
            ? 'slds-card slds-card_boundary error-card'
            : 'slds-card slds-card_boundary';
    }
}