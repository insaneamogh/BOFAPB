import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import initData from '@salesforce/apex/UST_Agentforce_MeetingPrepComtroller.initData';
import getSummary from '@salesforce/apex/UST_Agentforce_MeetingPrepComtroller.getSummary';

export default class UST_Agentforce_MeetingPrep extends NavigationMixin(LightningElement) {
     _recordId;
     _hasInit = false;
    @api meetingType; // Accept meeting type from parent
    @api meetingPurpose; // Accept meeting purpose from parent
    @api meetingTitle;
    @api selectedDataCategories; // Accept selected data categories from parent
    @track correlationId;
    @track payloadJSON;
    @track error;
     @track summaryText = '';
    @track summaryError = '';
    @track summaryRendered = false;
    @track isLoadingSummary = false;
    @track isLoadingData = false;
    @track showModal = false;
    @track modalRecordId = '';
    @track modalObjectApiName = '';
    @track modalError = '';
    @track parsedDataCategories = {};
    @track displayConfig = {
        cards: [],
        accordions: []
    };

     @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        if (value && !this._hasInit) {
            this._hasInit = true;
            this.fetchInitData();
        }
    }

    get isAdhocLoad() {
    return this.meetingType === 'Adhoc';
    }

    fetchInitData() {
        this.isLoadingData = true;
        this.isLoadingSummary = true;
        initData({
            partyId: this.recordId,
            meetingType: 'Quarterly Check-In',
            windowDays: 90
        })
        .then(result => {
            this.correlationId = result.correlationId;
            this.payloadJSON = result.payloadJSON;

            try {
                this.parsePayloadData();
                this.initializeDisplayConfig();
            } catch (processingError) {
                console.error('Error during data processing:', processingError);
                this.error = `Data processing failed: ${processingError.message}`;
            }

            // Data is now ready - stop data loading (always set this to false)
            this.isLoadingData = false;

            // Start AI summary generation independently
            this.handleGetSummary();
        })
        .catch(error => {
            console.error('initData failed:', error);
            this.error = error.body ? error.body.message : error.message;
            this.isLoadingData = false;
            this.isLoadingSummary = false;
        });
    }

     handleGetSummary() {
        // Summary loading is already started in fetchInitData

        // Determine prompt template based on meeting type
        let promptTemplateName = 'CP_Test_Quarterly'; // Default for Quarterly
        if (this.meetingType === 'Adhoc') {
            promptTemplateName = 'CP_Test_Ad_Hoc';
        }

        getSummary({
            payloadJSON: JSON.stringify(this.payloadJSON),
            promptTemplateName: promptTemplateName,
            meetingType: this.meetingType,
            meetingPurpose: this.meetingPurpose,
            selectedDataCategories: this.selectedDataCategories
        })
        .then(result => {
            this.summaryText = result;
            this.summaryError = '';
            this.summaryRendered = false; // Reset to trigger re-rendering
            this.isLoadingSummary = false; // Summary is now ready
            this.dispatchEvent(new CustomEvent('summaryloaded'));
        })
        .catch(error => {
            this.summaryText = '';
            this.summaryError = error.body ? error.body.message : error.message;
            this.isLoadingSummary = false; // Stop loading even on error
            this.dispatchEvent(new CustomEvent('summaryloaded'));
        });
    }

    get prettyPayload() {
        return this.payloadJSON ? JSON.stringify(this.payloadJSON, null, 2) : '';
    }

    // Enhanced data parsing with section-based error isolation
    parsePayloadData() {
        if (!this.payloadJSON || !this.payloadJSON.r_PayloadJSON) {
            console.warn('No payload data to parse');
            this.parsedDataCategories = {};
            return;
        }

        const payloadData = this.payloadJSON.r_PayloadJSON;
        let jsonString = '';

        // Convert to string if needed
        if (typeof payloadData === 'string') {
            jsonString = payloadData;
        } else if (typeof payloadData === 'object' && payloadData !== null) {
            // Already an object, process directly
            this.processParsedObject(payloadData);
            return;
        } else {
            console.error(`Unexpected payload data type: ${typeof payloadData}`);
            this.parsedDataCategories = this.createErrorSection('Invalid Data Type', `Unexpected payload data type: ${typeof payloadData}`);
            return;
        }

        console.log('Starting section-based JSON parsing...');

        // STEP 1: Truncate problematic Description fields BEFORE any JSON parsing attempts
        jsonString = this.truncateDescriptions(jsonString);

        // Store the processed JSON for potential salvage operations
        this.lastProcessedJsonString = jsonString;

        // STEP 2: Try to parse the full JSON first
        let fullParsedObject = null;
        try {
            const cleanedJSON = this.cleanupJSON(jsonString);
            fullParsedObject = JSON.parse(cleanedJSON);
            console.log('Successfully parsed complete JSON');
            this.processParsedObject(fullParsedObject);
            return;
        } catch (fullParseError) {
            console.warn('Full JSON parsing failed, attempting section-based parsing:', fullParseError.message);
        }

        // If full parsing fails, parse sections individually
        this.parseJSONSections(jsonString);
    }

    // Parse JSON sections individually to isolate errors
    parseJSONSections(jsonString) {
        const dataCategories = {};
        const knownSections = [
            'Opportunities',
            'FinancialSummary',
            'Financial Summary',
            'Employment',
            'Education',
            'MeaningfulInteractions',
            'Meaningful Interactions',
            'ClientServiceInteractions',
            'PreferredRewards',
            'RecentlyOpenedAccounts',
            'UpcomingTasks',
            'OverdueTasks',
            'LifeEvents',
            'CuratedEvents'
        ];

        console.log('Attempting section-based parsing for known sections...');

        knownSections.forEach(sectionName => {
            try {
                const sectionData = this.extractJSONSection(jsonString, sectionName);
                if (sectionData !== null) {
                    // Successfully extracted and parsed this section
                    const processedData = this.processDataForStandardComponents(sectionData);

                    dataCategories[sectionName] = {
                        key: sectionName,
                        type: Array.isArray(sectionData) ? 'array' : typeof sectionData,
                        data: processedData,
                        count: Array.isArray(sectionData) ? sectionData.length : null,
                        fields: this.extractFieldNames(sectionData),
                        displayName: this.formatDisplayName(sectionName),
                        originalValue: sectionData,
                        parseStatus: 'success'
                    };

                    console.log(`Successfully parsed section '${sectionName}':`, {
                        type: dataCategories[sectionName].type,
                        count: dataCategories[sectionName].count
                    });
                }
            } catch (sectionError) {
                console.error(`Failed to parse section '${sectionName}':`, sectionError.message);

                // Create placeholder data instead of error for interaction sections
                if (sectionName.includes('Interactions')) {
                    dataCategories[sectionName] = this.createPlaceholderInteractionData(sectionName);
                } else {
                    // For non-interaction sections, still show error card
                    dataCategories[sectionName] = {
                        key: sectionName,
                        type: 'error',
                        data: {
                            error: `Failed to parse ${sectionName}: ${sectionError.message}`,
                            message: 'This section contains malformed data and could not be processed.'
                        },
                        count: null,
                        fields: ['error', 'message'],
                        displayName: this.formatDisplayName(sectionName),
                        parseStatus: 'error'
                    };
                }
            }
        });

        this.parsedDataCategories = dataCategories;

        if (this.meetingType === 'Adhoc') {
            this.filterParsedDataCategories(this.selectedDataCategories);
        }

        console.log('Section-based parsing completed. Results:', Object.keys(dataCategories));
    }

    // Extract a specific section from the JSON string
    extractJSONSection(jsonString, sectionName) {
        // Create regex patterns to match the section
        const patterns = [
            // Pattern for array sections: "SectionName": [...]
            new RegExp(`"${sectionName}"\\s*:\\s*\\[(.*?)\\](?=\\s*[,}]|$)`, 's'),
            // Pattern for object sections: "SectionName": {...}
            new RegExp(`"${sectionName}"\\s*:\\s*\\{([^{}]*(?:\\{[^{}]*\\}[^{}]*)*)\\}(?=\\s*[,}]|$)`, 's')
        ];

        for (const pattern of patterns) {
            const match = jsonString.match(pattern);
            if (match) {
                try {
                    let sectionJSON = '';

                    // Determine if it's an array or object based on the pattern
                    if (pattern.source.includes('\\[')) {
                        // Array section
                        sectionJSON = `[${match[1]}]`;
                    } else {
                        // Object section
                        sectionJSON = `{${match[1]}}`;
                    }

                    // Clean up the section JSON
                    const cleanedSection = this.cleanupJSON(sectionJSON);

                    // Parse and return
                    return JSON.parse(cleanedSection);

                } catch (sectionParseError) {
                    console.warn(`Failed to parse extracted section '${sectionName}':`, sectionParseError.message);

                    // Try more aggressive cleanup for this section
                    try {
                        const aggressivelyCleanedSection = this.aggressiveCleanupSection(match[0], sectionName);
                        return JSON.parse(aggressivelyCleanedSection);
                    } catch (aggressiveError) {
                        console.error(`Aggressive cleanup also failed for '${sectionName}':`, aggressiveError.message);
                        throw sectionParseError; // Re-throw original error
                    }
                }
            }
        }

        // Section not found
        return null;
    }

    // More aggressive cleanup for problem sections
    aggressiveCleanupSection(sectionMatch, sectionName) {
        console.log(`Applying aggressive cleanup to section: ${sectionName}`);

        let cleaned = sectionMatch;

        // Fix common issues specific to problematic sections
        if (sectionName.includes('Interactions')) {
            // Fix unclosed HTML tags
            cleaned = cleaned.replace(/<a\s+href="[^"]*">/g, ''); // Remove opening <a> tags
            cleaned = cleaned.replace(/<\/a>/g, ''); // Remove closing </a> tags

            // Fix unclosed quotes in descriptions
            cleaned = cleaned.replace(/"Description":\s*"([^"]*[^\\])"?\s*([,}])/g, '"Description":"$1"$2');

            // Fix malformed object endings
            cleaned = cleaned.replace(/([^"\\])"?\s*\}\s*{\s*"/g, '$1"},"');
        }

        // General fixes
        cleaned = cleaned.replace(/,(\s*[}\]])/g, '$1'); // Remove trailing commas
        cleaned = cleaned.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":'); // Quote keys

        return cleaned;
    }

    // Process an already-parsed object
    processParsedObject(rawPayload) {
        const dataCategories = {};

        // Automatically detect data types and structure
        Object.keys(rawPayload).forEach(key => {
            try {
                const value = rawPayload[key];
                // Process and clean the data for better compatibility with standard components
                const processedData = this.processDataForStandardComponents(value);

                dataCategories[key] = {
                    key: key,
                    type: Array.isArray(value) ? 'array' : typeof value,
                    data: processedData,
                    count: Array.isArray(value) ? value.length : null,
                    fields: this.extractFieldNames(value),
                    displayName: this.formatDisplayName(key),
                    originalValue: value,
                    parseStatus: 'success'
                };

                console.log(`Processed data category '${key}':`, {
                    type: dataCategories[key].type,
                    count: dataCategories[key].count,
                    fieldsCount: dataCategories[key].fields.length
                });
            } catch (categoryError) {
                console.error(`Error processing category '${key}':`, categoryError);

                // Add error entry for this category
                dataCategories[key] = this.createErrorSection(key, `Processing error: ${categoryError.message}`);
            }
        });

        this.parsedDataCategories = dataCategories;

        if (this.meetingType === 'Adhoc') {
            this.filterParsedDataCategories(this.selectedDataCategories);
        }

        console.log('Object processing completed:', Object.keys(dataCategories));
    }

    // Helper method to create error sections
    createErrorSection(sectionName, errorMessage) {
        return {
            [sectionName]: {
                key: sectionName,
                type: 'error',
                data: {
                    error: errorMessage,
                    message: 'This section contains malformed data and could not be processed.'
                },
                count: null,
                fields: ['error', 'message'],
                displayName: this.formatDisplayName(sectionName),
                parseStatus: 'error'
            }
        };
    }

    // Create placeholder data for interaction sections that failed to parse
    createPlaceholderInteractionData(sectionName) {
        console.log(`Attempting to salvage individual records from failed section: ${sectionName}`);

        // First, try to extract individual interaction objects from the malformed section
        const salvageAttempt = this.attemptInteractionSalvage(sectionName);

        if (salvageAttempt && salvageAttempt.length > 0) {
            console.log(`Successfully salvaged ${salvageAttempt.length} interactions from ${sectionName}`);

            return {
                key: sectionName,
                type: 'array',
                data: salvageAttempt,
                count: salvageAttempt.length,
                fields: this.extractFieldNames(salvageAttempt),
                displayName: this.formatDisplayName(sectionName),
                parseStatus: 'partial',
                originalValue: salvageAttempt
            };
        }

        // If salvage fails, fall back to placeholder
        console.log(`Could not salvage data from ${sectionName}, using placeholder`);
        const placeholderInteractions = [
            {
                Id: 'placeholder-1',
                Subject: 'Data Display Issue',
                Description: 'Text cannot be displayed due to formatting issues. Please open the related record to view full details.',
                isPlaceholder: true
            }
        ];

        return {
            key: sectionName,
            type: 'array',
            data: placeholderInteractions,
            count: placeholderInteractions.length,
            fields: ['Id', 'Subject', 'Description'],
            displayName: this.formatDisplayName(sectionName),
            parseStatus: 'placeholder',
            originalValue: placeholderInteractions
        };
    }

    // Attempt to salvage individual interaction records from malformed JSON
    attemptInteractionSalvage(sectionName) {
        console.log(`Attempting to salvage individual interactions from ${sectionName}`);

        try {
            // Get the original JSON string (after description cleanup)
            const originalJson = this.lastProcessedJsonString || '';
            if (!originalJson) {
                console.log('No original JSON string available for salvage');
                return null;
            }

            // Look for individual interaction objects within the section
            // Pattern: { "Id":"...", "Subject":"...", "Description":"..." }
            const interactionPattern = /\{\s*"Id"\s*:\s*"([^"]+)"\s*,\s*"Subject"\s*:\s*"([^"]+)"\s*,\s*"Description"\s*:\s*"([^"]*(?:\\.[^"]*)*)"\s*\}/g;

            const salvaged = [];
            let match;

            while ((match = interactionPattern.exec(originalJson)) !== null) {
                try {
                    const interaction = {
                        Id: match[1],
                        Subject: match[2],
                        Description: match[3],
                        isSalvaged: true
                    };

                    // Basic validation - make sure we have required fields
                    if (interaction.Id && interaction.Subject) {
                        salvaged.push(interaction);
                        console.log(`Salvaged interaction: ${interaction.Subject}`);
                    }
                } catch (e) {
                    console.log(`Failed to salvage individual interaction: ${e.message}`);
                }
            }

            // If we found some interactions, return them
            if (salvaged.length > 0) {
                console.log(`Successfully salvaged ${salvaged.length} interactions`);
                return salvaged;
            }

            // Try a more aggressive salvage approach - look for any text that looks like interactions
            return this.attemptAggressiveInteractionSalvage(originalJson, sectionName);

        } catch (error) {
            console.error(`Error during interaction salvage: ${error.message}`);
            return null;
        }
    }

    // More aggressive salvage attempt - extract partial data
    attemptAggressiveInteractionSalvage(jsonString, sectionName) {
        console.log(`Attempting aggressive salvage for ${sectionName}`);

        try {
            const salvaged = [];

            // Look for ID patterns that might indicate interaction records
            const idPattern = /"Id"\s*:\s*"(00[UuGgTt][a-zA-Z0-9]{12,15})"/g;
            const foundIds = [];
            let match;

            while ((match = idPattern.exec(jsonString)) !== null) {
                foundIds.push(match[1]);
            }

            // For each ID found, try to find associated Subject
            foundIds.forEach((id, index) => {
                try {
                    // Create a basic interaction record with what we can safely extract
                    const interaction = {
                        Id: id,
                        Subject: `Interaction ${index + 1}`,
                        Description: 'Full details cannot be displayed due to data formatting issues. Please open this record to view complete information.',
                        isSalvaged: true,
                        isPartial: true
                    };

                    salvaged.push(interaction);
                } catch (e) {
                    console.log(`Failed to create salvaged interaction for ID ${id}: ${e.message}`);
                }
            });

            if (salvaged.length > 0) {
                console.log(`Aggressively salvaged ${salvaged.length} interaction stubs`);
                return salvaged;
            }

            return null;
        } catch (error) {
            console.error(`Error during aggressive salvage: ${error.message}`);
            return null;
        }
    }

    // Truncate problematic Description fields to prevent JSON parsing errors
    truncateDescriptions(jsonString) {
        console.log('truncateDescriptions: Processing description fields...');

        if (!jsonString || typeof jsonString !== 'string') {
            return jsonString;
        }

        // Strategy: Find "Description":"..." patterns and truncate/clean the content
        // The problem is that the original has malformed content that breaks JSON parsing
        // We need to handle cases where the quote might not be properly closed

        let processedString = jsonString;

        // First pass: Handle properly quoted descriptions and truncate if needed
        processedString = processedString.replace(
            /"Description"\s*:\s*"([^"]*(?:\\.[^"]*)*)"/g,
            (match, content) => {
                if (content.length > 100) {
                    const truncated = content.substring(0, 100).trim();
                    console.log(`truncateDescriptions: Truncated description from ${content.length} to ${truncated.length} characters`);
                    // Clean the truncated content of control characters
                    const cleanContent = truncated
                        .replace(/[\n\r\t\f\b]/g, ' ')  // Replace control chars with spaces
                        .replace(/\s+/g, ' ')           // Normalize whitespace
                        .trim();
                    return `"Description":"${cleanContent}..."`;
                }

                // Even if not truncating, clean control characters
                const cleanContent = content
                    .replace(/[\n\r\t\f\b]/g, ' ')  // Replace control chars with spaces
                    .replace(/\s+/g, ' ')           // Normalize whitespace
                    .trim();

                return `"Description":"${cleanContent}"`;
            }
        );

        // Second pass: Handle malformed descriptions (unclosed quotes, etc.)
        // Look for patterns like "Description":"...stuff... that might not end properly
        processedString = processedString.replace(
            /"Description"\s*:\s*"([^"]{0,200})[^"]*"?\s*([,}])/g,
            (match, content, terminator) => {
                // Take first 100 characters and clean them
                const truncated = content.substring(0, 100).trim();
                const cleanContent = truncated
                    .replace(/[\n\r\t\f\b]/g, ' ')  // Replace control chars with spaces
                    .replace(/\s+/g, ' ')           // Normalize whitespace
                    .replace(/[<>]/g, '')           // Remove angle brackets that might be malformed HTML
                    .trim();

                console.log(`truncateDescriptions: Fixed malformed description, truncated to: "${cleanContent}..."`);
                return `"Description":"${cleanContent}..."${terminator}`;
            }
        );

        console.log('truncateDescriptions: Description field processing completed');
        return processedString;
    }

    // Enhanced JSON cleanup with better error handling and position tracking
    cleanupJSON(jsonString) {
        if (!jsonString || typeof jsonString !== 'string') {
            console.warn('cleanupJSON: Invalid input type');
            return jsonString;
        }

        console.log('cleanupJSON: Starting cleanup process...');
        console.log('cleanupJSON: Input length:', jsonString.length);

        try {
            // First, let's try parsing as-is to see if it's already valid
            JSON.parse(jsonString);
            console.log('cleanupJSON: JSON is already valid, returning original');
            return jsonString;
        } catch (originalError) {
            console.log('cleanupJSON: Initial parsing failed:', originalError.message);
            console.log('cleanupJSON: Error at position:', this.extractPositionFromError(originalError.message));
        }

        let cleaned = jsonString.trim();
        const cleanupSteps = [];

        try {
            // Step 1: Handle control characters more carefully
            console.log('cleanupJSON: Step 1 - Handling control characters');
            const beforeControlChars = cleaned.length;
            cleaned = this.handleControlCharacters(cleaned);
            if (cleaned.length !== beforeControlChars) {
                cleanupSteps.push('Control characters handled');
            }
            this.validateCleanupStep(cleaned, 'Control characters', cleanupSteps);

            // Step 2: Remove trailing commas (most common issue)
            console.log('cleanupJSON: Step 2 - Removing trailing commas');
            const beforeCommas = cleaned;
            cleaned = cleaned.replace(/,(\s*[}\]])/g, '$1');
            if (cleaned !== beforeCommas) {
                cleanupSteps.push('Trailing commas removed');
            }
            this.validateCleanupStep(cleaned, 'Trailing commas', cleanupSteps);

            // Step 3: Fix unquoted property names
            console.log('cleanupJSON: Step 3 - Fixing unquoted property names');
            const beforeProps = cleaned;
            cleaned = cleaned.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');
            if (cleaned !== beforeProps) {
                cleanupSteps.push('Property names quoted');
            }
            this.validateCleanupStep(cleaned, 'Property names', cleanupSteps);

            // Step 4: Fix comma-separated numbers in values (conservative approach)
            console.log('cleanupJSON: Step 4 - Fixing comma-separated numbers');
            const beforeNumbers = cleaned;
            cleaned = this.fixCommaInNumbers(cleaned);
            if (cleaned !== beforeNumbers) {
                cleanupSteps.push('Comma-separated numbers fixed');
            }
            this.validateCleanupStep(cleaned, 'Comma-separated numbers', cleanupSteps);

            // Step 5: Handle unquoted string values
            console.log('cleanupJSON: Step 5 - Handling unquoted string values');
            const beforeValues = cleaned;
            cleaned = this.handleUnquotedValues(cleaned);
            if (cleaned !== beforeValues) {
                cleanupSteps.push('Unquoted values handled');
            }
            this.validateCleanupStep(cleaned, 'Unquoted values', cleanupSteps);

            // Step 6: Final validation
            console.log('cleanupJSON: Step 6 - Final validation');
            JSON.parse(cleaned);
            console.log('cleanupJSON: SUCCESS! Applied cleanup steps:', cleanupSteps);
            return cleaned;

        } catch (cleanupError) {
            console.error('cleanupJSON: Cleanup failed at step:', cleanupError.message);
            console.error('cleanupJSON: Applied steps before failure:', cleanupSteps);
            console.error('cleanupJSON: Error position:', this.extractPositionFromError(cleanupError.message));

            // Log a portion of the JSON around the error position for debugging
            const errorPos = this.extractPositionFromError(cleanupError.message);
            if (errorPos !== null) {
                const start = Math.max(0, errorPos - 100);
                const end = Math.min(cleaned.length, errorPos + 100);
                console.error('cleanupJSON: Context around error:', cleaned.substring(start, end));
            }

            console.log('cleanupJSON: Returning original string due to cleanup failure');
            return jsonString;
        }
    }

    // Extract position number from JSON parsing error messages
    extractPositionFromError(errorMessage) {
        if (!errorMessage) return null;

        const positionMatch = errorMessage.match(/position (\d+)/);
        return positionMatch ? parseInt(positionMatch[1], 10) : null;
    }

    // Validate a cleanup step by attempting to parse the JSON
    validateCleanupStep(jsonString, stepName, cleanupSteps) {
        try {
            JSON.parse(jsonString);
            console.log(`cleanupJSON: ${stepName} step - JSON is now valid!`);
            return true;
        } catch (e) {
            console.log(`cleanupJSON: ${stepName} step - Still invalid:`, e.message);
            return false;
        }
    }

    // Handle control characters more safely
    handleControlCharacters(jsonString) {
        // Only escape control characters that are NOT within quoted strings
        let result = '';
        let inString = false;
        let escapeNext = false;

        for (let i = 0; i < jsonString.length; i++) {
            const char = jsonString[i];
            const prevChar = i > 0 ? jsonString[i - 1] : '';

            if (escapeNext) {
                result += char;
                escapeNext = false;
                continue;
            }

            if (char === '\\') {
                result += char;
                escapeNext = true;
                continue;
            }

            if (char === '"' && prevChar !== '\\') {
                inString = !inString;
                result += char;
                continue;
            }

            // Only escape control characters outside of strings
            if (!inString) {
                switch (char) {
                    case '\n':
                        result += '\\n';
                        break;
                    case '\r':
                        result += '\\r';
                        break;
                    case '\t':
                        result += '\\t';
                        break;
                    case '\f':
                        result += '\\f';
                        break;
                    case '\b':
                        result += '\\b';
                        break;
                    default:
                        result += char;
                }
            } else {
                result += char;
            }
        }

        return result;
    }

    // Fix comma-separated numbers more conservatively
    fixCommaInNumbers(jsonString) {
        // Look for patterns like "Amount": 5,000 and convert to "Amount": "5,000"
        // But be very careful not to break actual object/array structure
        return jsonString.replace(
            /"(Amount|Balance|Total|Revenue|Credit|Deposit)":\s*(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)/gi,
            '"$1": "$2"'
        );
    }

    // Handle unquoted values more intelligently
    handleUnquotedValues(jsonString) {
        // This is a complex operation, so we'll do it character by character
        // to maintain context of whether we're inside strings, objects, etc.

        const result = [];
        let i = 0;
        let inString = false;
        let escapeNext = false;

        while (i < jsonString.length) {
            const char = jsonString[i];

            if (escapeNext) {
                result.push(char);
                escapeNext = false;
                i++;
                continue;
            }

            if (char === '\\') {
                result.push(char);
                escapeNext = true;
                i++;
                continue;
            }

            if (char === '"') {
                inString = !inString;
                result.push(char);
                i++;
                continue;
            }

            // Look for unquoted values after colons
            if (!inString && char === ':') {
                result.push(char);
                i++;

                // Skip whitespace
                while (i < jsonString.length && /\s/.test(jsonString[i])) {
                    result.push(jsonString[i]);
                    i++;
                }

                // Check if the next value is unquoted
                if (i < jsonString.length) {
                    const valueStart = i;
                    const value = this.extractUnquotedValue(jsonString, i);

                    if (value && value.needsQuoting) {
                        result.push('"' + value.escapedValue + '"');
                        i = valueStart + value.originalLength;
                    } else {
                        result.push(jsonString[i]);
                        i++;
                    }
                }
            } else {
                result.push(char);
                i++;
            }
        }

        return result.join('');
    }

    // Extract and analyze an unquoted value
    extractUnquotedValue(jsonString, startIndex) {
        if (startIndex >= jsonString.length) return null;

        const char = jsonString[startIndex];

        // If it starts with a quote, bracket, or brace, it's not an unquoted value
        if (char === '"' || char === '[' || char === '{') {
            return null;
        }

        // Find the end of the value (until comma, closing bracket/brace, or end)
        let endIndex = startIndex;
        let braceDepth = 0;
        let bracketDepth = 0;

        while (endIndex < jsonString.length) {
            const c = jsonString[endIndex];

            if (c === '{') braceDepth++;
            else if (c === '}') braceDepth--;
            else if (c === '[') bracketDepth++;
            else if (c === ']') bracketDepth--;
            else if ((c === ',' || c === '}' || c === ']') && braceDepth === 0 && bracketDepth === 0) {
                break;
            }

            endIndex++;
        }

        const originalValue = jsonString.substring(startIndex, endIndex).trim();

        // Check if this value needs quoting
        if (this.shouldQuoteValue(originalValue)) {
            return {
                needsQuoting: true,
                originalLength: endIndex - startIndex,
                escapedValue: originalValue.replace(/"/g, '\\"'),
                originalValue: originalValue
            };
        }

        return null;
    }

    // Determine if a value should be quoted
    shouldQuoteValue(value) {
        if (!value) return false;

        // Don't quote boolean, null, or numeric values
        if (/^(true|false|null)$/i.test(value)) return false;
        if (/^-?\d+\.?\d*([eE][+-]?\d+)?$/.test(value)) return false;

        // Quote everything else (strings, currency, percentages, etc.)
        return true;
    }

    // Fallback parsing strategies for severely malformed JSON
    tryFallbackParsing(originalJson) {
        console.log('Attempting fallback parsing strategies...');

        const strategies = [
            // Strategy 1: Try to fix common Salesforce Flow issues
            () => {
                let fixed = originalJson
                    // Fix trailing commas in arrays and objects
                    .replace(/,\s*]/g, ']')
                    .replace(/,\s*}/g, '}')
                    // Fix comma-separated numbers (like "Balance":5,000 -> "Balance":5000)
                    .replace(/:\s*(\d+),(\d+)/g, ':$1$2')
                    // Fix unquoted numeric values by keeping them as numbers
                    .replace(/"Amount":\s*(\d+)/g, '"Amount":$1')
                    .replace(/"Balance":\s*(\d+)/g, '"Balance":$1')
                    .replace(/"Total [^"]*":\s*(\d+)/g, (match, num) => match.replace(num, num))
                    // Keep Revenue as number
                    .replace(/"Rolling 12 Month Revenue":\s*(\d+)/g, '"Rolling 12 Month Revenue":$1');

                return JSON.parse(fixed);
            },

            // Strategy 2: Use eval as last resort (with safety checks)
            () => {
                // Only try this if the JSON looks safe (no functions, no suspicious patterns)
                if (!/function|eval|\(|\)|script/i.test(originalJson)) {
                    console.warn('Attempting eval fallback - this should be avoided in production');
                    return eval('(' + originalJson + ')');
                }
                return null;
            },

            // Strategy 3: Manual key-value extraction for known patterns
            () => {
                console.log('Attempting manual extraction...');
                return this.manualJsonExtraction(originalJson);
            }
        ];

        for (let i = 0; i < strategies.length; i++) {
            try {
                const result = strategies[i]();
                if (result && typeof result === 'object') {
                    console.log(`Fallback strategy ${i + 1} succeeded`);
                    return result;
                }
            } catch (e) {
                console.log(`Fallback strategy ${i + 1} failed:`, e.message);
            }
        }

        console.error('All fallback parsing strategies failed');
        return null;
    }

    // Manual extraction for known JSON patterns (most reliable fallback)
    manualJsonExtraction(jsonString) {
        const result = {};

        // Extract arrays and objects using regex patterns specific to our expected data
        const patterns = {
            'Opportunities': /"Opportunities":\s*\[(.*?)\]/s,
            'Financial Summary': /"Financial Summary":\s*\{([^}]*)\}/,
            'Employment': /"Employment":\s*\[(.*?)\]/s,
            'Education': /"Education":\s*\[(.*?)\]/s,
            'Meaningful Interactions': /"Meaningful Interactions":\s*\[(.*?)\]/s,
            'ClientServiceInteractions': /"ClientServiceInteractions":\s*\[(.*?)\]/s
        };

        Object.entries(patterns).forEach(([key, pattern]) => {
            const match = jsonString.match(pattern);
            if (match) {
                try {
                    if (key === 'Financial Summary') {
                        // Parse object
                        const objContent = '{' + match[1] + '}';
                        result[key] = JSON.parse(objContent);
                    } else {
                        // Parse array
                        const arrayContent = '[' + match[1] + ']';
                        result[key] = JSON.parse(arrayContent);
                    }
                } catch (e) {
                    console.warn(`Failed to parse ${key} manually:`, e.message);
                    result[key] = key === 'Financial Summary' ? {} : [];
                }
            }
        });

        return Object.keys(result).length > 0 ? result : null;
    }

    // Process data to make it compatible with standard Lightning components
    processDataForStandardComponents(data) {
        if (Array.isArray(data)) {
            return data.map(item => this.processItemForStandardComponents(item));
        } else if (typeof data === 'object' && data !== null) {
            return this.processItemForStandardComponents(data);
        }
        return data;
    }

    // Process individual items to clean up data formatting
    processItemForStandardComponents(item) {
        if (typeof item !== 'object' || item === null) {
            return item;
        }

        const processedItem = {};
        Object.keys(item).forEach(key => {
            let value = item[key];

            // Handle date fields - convert readable date strings to Date objects
            if (this.isDateField(key, value)) {
                value = this.parseDate(value);
            }
            // Handle currency fields - ensure they're numbers (should already be fixed per user)
            else if (this.isCurrencyField(key, value)) {
                value = this.parseCurrency(value);
            }

            processedItem[key] = value;
        });

        return processedItem;
    }

    // Check if a field represents a date
    isDateField(fieldName, value) {
        const dateFieldNames = ['date', 'closedate', 'startdate', 'enddate', 'createddate', 'modifieddate'];
        const isDateFieldName = dateFieldNames.some(dateField =>
            fieldName.toLowerCase().includes(dateField)
        );

        // Also check if the value looks like a readable date string
        const isDateString = typeof value === 'string' &&
            /^[A-Za-z]+\s+\d{1,2},\s+\d{4}$/.test(value.trim()); // "November 23, 2022"

        return isDateFieldName || isDateString;
    }

    // Check if a field represents currency
    isCurrencyField(fieldName, value) {
        const currencyFieldNames = ['amount', 'balance', 'total', 'revenue', 'credit', 'deposit'];
        return currencyFieldNames.some(currencyField =>
            fieldName.toLowerCase().includes(currencyField)
        ) && (typeof value === 'string' && value.includes('$'));
    }

    // Parse date strings into Date objects
    parseDate(dateString) {
        if (!dateString || typeof dateString !== 'string') {
            return dateString;
        }

        try {
            // Handle "November 23, 2022" format
            const date = new Date(dateString);

            // Verify the date is valid
            if (isNaN(date.getTime())) {
                console.warn('Invalid date string:', dateString);
                return dateString; // Return original if parsing fails
            }

            return date;
        } catch (error) {
            console.warn('Error parsing date:', dateString, error);
            return dateString; // Return original if parsing fails
        }
    }

    // Parse currency strings into numbers
    parseCurrency(currencyString) {
        if (typeof currencyString === 'number') {
            return currencyString;
        }

        if (typeof currencyString === 'string') {
            // Remove currency symbols and commas, then parse
            const numStr = currencyString.replace(/[$,]/g, '');
            const num = parseFloat(numStr);
            return isNaN(num) ? 0 : num;
        }

        return 0;
    }

    // Extract field names from data for flexible rendering
    extractFieldNames(data) {
        if (Array.isArray(data) && data.length > 0) {
            // Get all unique field names from array items
            const allFields = new Set();
            data.forEach(item => {
                if (typeof item === 'object' && item !== null) {
                    Object.keys(item).forEach(field => allFields.add(field));
                }
            });
            return Array.from(allFields);
        }
        if (typeof data === 'object' && data !== null) {
            return Object.keys(data);
        }
        return [];
    }

    // Format key names for display (convert camelCase/PascalCase to readable format)
    formatDisplayName(key) {
        return key
            .replace(/([A-Z])/g, ' $1') // Add space before capital letters
            .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
            .trim();
    }

    // Initialize display configuration based on parsed data
    initializeDisplayConfig() {
        const cards = [];
        const accordions = [];

        try {
            // Default configuration mapping - this could be made configurable later
            Object.keys(this.parsedDataCategories).forEach(key => {
                const category = this.parsedDataCategories[key];

                // Decide whether to show as card or accordion based on data characteristics
                if (this.shouldShowAsCard(category)) {
                    cards.push(this.createCardConfig(category));
                }

                // Most data can also be shown as accordion (detailed view)
                if (this.shouldShowAsAccordion(category)) {
                    accordions.push(this.createAccordionConfig(category));
                }
            });

            this.displayConfig = { cards, accordions };
        } catch (error) {
            console.error('Error initializing display config:', error);
            // Ensure we have a valid displayConfig even on error
            this.displayConfig = { cards: [], accordions: [] };
        }
    }

     filterParsedDataCategories(selectedDataCategories) {
            Object.keys(this.parsedDataCategories).forEach(key => {
                console.log('parsedDataCategories-key', key);
                console.log('parsedDataCategoryValues:', JSON.stringify(this.parsedDataCategories[key]));
            if (!selectedDataCategories.includes(key)){
            delete this.parsedDataCategories[key];
            }
        });
        }

    // Determine if data should be displayed as a card
    shouldShowAsCard(category) {
        // Show as card if:
        // 1. It's a financial summary (object with numeric values)
        // 2. It's a PreferredRewards object (should display as table)
        // 3. It's a small array (< 6 items) with important data - BUT NOT Opportunities (they get datatable)
        // 4. It's a single important metric
        // 5. Show error sections as cards for visibility

        if (category.type === 'error') {
            return true; // Show errors prominently as cards
        }

        if (category.type === 'object' && category.key.toLowerCase().includes('financial')) {
            return true;
        }

        // Skip opportunities for cards since they now use datatable
        if (category.key === 'Opportunities') {
            return false;
        }

        if (category.type === 'array' && category.count > 0 && category.count <= 5) {
            return ['Recent Activities', 'Tasks'].includes(category.key);
        }

        return false;
    }

    // Determine if data should be displayed as an accordion
    shouldShowAsAccordion(category) {
        // Show as accordion if:
        // 1. It's an array with items (including Opportunities which will use datatable inside accordion)
        // 2. It's an object with multiple properties
        // 3. It's detailed data that takes up space
        // 4. Don't show error sections as accordions (they're already cards)
        // 5. Show placeholder sections as accordions so users can see the message

        if (category.type === 'error') {
            return false; // Errors are shown as cards only
        }

        return (category.type === 'array' && category.count > 0) ||
               (category.type === 'object' && category.fields.length > 0);
    }

    // Create card configuration
    createCardConfig(category) {
        return {
            key: category.key,
            displayName: category.displayName,
            type: category.type,
            data: category.data,
            count: category.count,
            icon: this.getIconForCategory(category.key, category.parseStatus),
            priority: this.getPriorityForCategory(category.key, category.parseStatus),
            parseStatus: category.parseStatus || 'success',
            isError: category.type === 'error'
        };
    }

    // Create accordion configuration
    createAccordionConfig(category) {
        return {
            key: category.key,
            displayName: category.displayName,
            type: category.type,
            data: category.data,
            count: category.count,
            fields: category.fields,
            icon: this.getIconForCategory(category.key, category.parseStatus),
            priority: this.getPriorityForCategory(category.key, category.parseStatus),
            recordType: this.getRecordTypeForCategory(category.key),
            useDataTable: category.key === 'Opportunities', // Flag to use datatable instead of list
            parseStatus: category.parseStatus || 'success',
            isPlaceholder: category.parseStatus === 'placeholder'
        };
    }

    // Get appropriate icon for data category
    getIconForCategory(key, parseStatus = 'success') {
        // Check parse status to determine appropriate icon
        if (parseStatus === 'error') {
            return 'utility:error';
        }

        // Check if this is a placeholder section
        if (parseStatus === 'placeholder') {
            return 'utility:info';
        }

        // Check if this is a partial data section
        if (parseStatus === 'partial') {
            return 'utility:warning';
        }

        const iconMap = {
            'Financial Summary': 'utility:money',
            'FinancialSummary': 'utility:money',
            'Opportunities': 'standard:opportunity',
            'Employment': 'utility:work',
            'Education': 'utility:education',
            'Meaningful Interactions': 'utility:comments',
            'MeaningfulInteractions': 'utility:comments',
            'ClientServiceInteractions': 'utility:customer_service',
            'Previous Interactions': 'utility:comments',
            'PreferredRewards': 'utility:rewards',
            'RecentlyOpenedAccounts': 'standard:account',
            'UpcomingTasks': 'utility:task',
            'OverdueTasks': 'utility:warning',
            'LifeEvents': 'utility:event',
            'CuratedEvents': 'utility:event'
        };

        return iconMap[key] || 'utility:list';
    }

    // Get priority for sorting (lower number = higher priority)
    getPriorityForCategory(key, parseStatus = 'success') {
        // Errors get highest priority (lowest number) so they're shown first
        if (parseStatus === 'error') {
            return 0;
        }

        const priorityMap = {
            'Financial Summary': 1,
            'FinancialSummary': 1,
            'Opportunities': 2,
            'Employment': 3,
            'Education': 4,
            'Meaningful Interactions': 5,
            'MeaningfulInteractions': 5,
            'ClientServiceInteractions': 6,
            'PreferredRewards': 7,
            'RecentlyOpenedAccounts': 8,
            'UpcomingTasks': 9,
            'OverdueTasks': 9,
            'LifeEvents': 10,
            'CuratedEvents': 11
        };

        return priorityMap[key] || 15;
    }

    // Get record type for linking
    getRecordTypeForCategory(key) {
        const recordTypeMap = {
            'Opportunities': 'Opportunity',
            'MeaningfulInteractions': 'Event',
            'Employment':'UST_Employment__c',
            'Education':'UST_Education__c',
            'PreferredRewards':'Account',
            'LifeEvents':'UST_Life_Events__c',
            'CuratedEvents':'CampaignMember',
            'ClientServiceInteractions':'Event',
            'RecentlyOpenedAccounts':'FinServ_FinancialAccount__c',
            'UpcomingTasks':'Task'
        };

        return recordTypeMap[key] || null;
    }


    // Computed properties for sorted display items
    get sortedCards() {
        if (!this.displayConfig.cards) return [];
        return [...this.displayConfig.cards].sort((a, b) => a.priority - b.priority);
    }

    get sortedAccordions() {
        if (!this.displayConfig.accordions) return [];
        return [...this.displayConfig.accordions].sort((a, b) => a.priority - b.priority);
    }

    get hasCards() {
        return this.sortedCards.length > 0;
    }

    get hasAccordions() {
        return this.sortedAccordions.length > 0;
    }

    // Add debug computed properties to help troubleshoot
    get dataLoadingState() {
        return {
            isLoadingData: this.isLoadingData,
            isLoadingSummary: this.isLoadingSummary,
            hasCards: this.hasCards,
            hasAccordions: this.hasAccordions,
            cardsCount: this.sortedCards.length,
            accordionsCount: this.sortedAccordions.length
        };
    }



    // Handle record click events from child components
    handleRecordClick(event) {
        const { recordId, recordType } = event.detail;

        if (recordId && recordId.length >= 15) {
            try {
                this.modalRecordId = recordId;
                this.modalObjectApiName = this.getObjectApiName(recordType);
                this.showModal = true;
            } catch (error) {
                console.error('Error opening modal from dynamic component:', error);
            }
        }
    }
     

    // Map record types from our links to proper Object API Names for lightning-record-form
    getObjectApiName(recordType) {
        const objectMapping = {
            'Account': 'Account',
            'Contact': 'Contact',
            'Opportunity': 'Opportunity',
            'Case': 'Case',
            'Lead': 'Lead',
            'Task': 'Task',
            'Event': 'Event',
            'Campaign': 'Campaign',
            'Product2': 'Product2',
            'Employment':'UST_Employment__c',
            'Education':'UST_Education__c',
            'PreferredRewards':'Account',
            'LifeEvent':'UST_Life_Events__c',
            'CuratedEvent':'CampaignMember',
            'ClientServiceInteraction':'Event',
            'Financial Account':'FinServ_FinancialAccount__c',
            // Add more mappings as needed for custom objects
        };

        return objectMapping[recordType] || recordType;
    }

    renderedCallback() {
        // Render the summary content manually to preserve all HTML attributes
        if (this.summaryText && !this.summaryRendered) {
            const summaryContainer = this.template.querySelector('.summary-content');
            if (summaryContainer) {
                // Set the HTML content directly
                console.log("summary text"+JSON.stringify(this.summaryText));
                summaryContainer.innerHTML = this.summaryText;

                // Apply SLDS styling classes to HTML formatting elements
                this.applySLDSStylestoSummary(summaryContainer);

                // Add event listeners to all record links
                const recordLinks = summaryContainer.querySelectorAll('a[data-record-id]');
                console.log("recordLinks"+JSON.stringify(recordLinks));
                recordLinks.forEach(link => {
                    // Remove any existing listeners to prevent duplicates
                    link.removeEventListener('click', this.boundHandleLinkClick);

                    // Add click event listener
                    this.boundHandleLinkClick = this.handleDirectLinkClick.bind(this);
                    link.addEventListener('click', this.boundHandleLinkClick);

                    // Add keyboard event listener for accessibility
                    link.removeEventListener('keydown', this.boundHandleLinkKeydown);
                    this.boundHandleLinkKeydown = this.handleDirectLinkKeydown.bind(this);
                    link.addEventListener('keydown', this.boundHandleLinkKeydown);
                });
                 console.log("UpdatedrecordLinks"+JSON.stringify(recordLinks));
                this.summaryRendered = true;
            }
        }
    }

    // Apply SLDS styling classes to HTML elements in the summary
    applySLDSStylestoSummary(container) {
        if (!container) return;

        // Style headings
        container.querySelectorAll('h1').forEach(el => {
            el.className = 'slds-text-heading_large slds-m-bottom_small slds-text-color_default';
        });

        container.querySelectorAll('h2').forEach(el => {
            el.className = 'slds-text-heading_medium slds-m-bottom_small slds-text-color_default';
        });

        container.querySelectorAll('h3').forEach(el => {
            el.className = 'slds-text-heading_small slds-m-bottom_x-small slds-text-color_default';
        });

        container.querySelectorAll('h4').forEach(el => {
            el.className = 'slds-text-body_regular slds-text-font_monospace slds-m-bottom_x-small slds-text-color_default';
        });

        // Style lists
        container.querySelectorAll('ul').forEach(el => {
            el.className = 'slds-list_dotted slds-m-bottom_medium slds-m-left_large';
        });

        container.querySelectorAll('ol').forEach(el => {
            el.className = 'slds-list_ordered slds-m-bottom_medium slds-m-left_large';
        });

        // Style list items
        container.querySelectorAll('li').forEach(el => {
            el.className = 'slds-item slds-m-bottom_x-small';
        });

        // Style paragraphs
        container.querySelectorAll('p').forEach(el => {
            el.className = 'slds-text-body_regular slds-m-bottom_small';
        });

        // Style strong/bold text
        container.querySelectorAll('strong, b').forEach(el => {
            el.className = 'slds-text-font_monospace';
        });

        // Style emphasis/italic text
        container.querySelectorAll('em, i').forEach(el => {
            el.className = 'slds-text-font_monospace';
        });
    }

    disconnectedCallback() {
        // Clean up event listeners to prevent memory leaks
        const summaryContainer = this.template.querySelector('.summary-content');
        if (summaryContainer) {
            const recordLinks = summaryContainer.querySelectorAll('a[data-record-id]');
            recordLinks.forEach(link => {
                link.removeEventListener('click', this.boundHandleLinkClick);
                link.removeEventListener('keydown', this.boundHandleLinkKeydown);
            });
        }
    }

    // Handle direct clicks on record links (bound to individual link elements)
    handleDirectLinkClick(event) {
        // Prevent default anchor behavior
        event.preventDefault();
        event.stopPropagation();

        const link = event.currentTarget; // Use currentTarget since we bound to the specific link
        const recordId = link.dataset.recordId;
        const recordType = link.dataset.recordType;
        console.log('recordType', recordType);
        this.modalObjectApiName = this.getObjectApiName(recordType);
        console.log('this.modalObjectApiName'+this.modalObjectApiName);

         if (
        recordType === 'Task' ||
        recordType === 'Event'
    ) {
        // Open standard Salesforce Lightning record page in a new tab
        window.open(`/lightning/r/${recordType}/${recordId}/view`, '_blank', 'noopener');
        return; // Stop any further modal logic!
    }
        if (recordId && recordId.length >= 15) {
            try {
                this.modalRecordId = recordId;
                this.modalObjectApiName = this.getObjectApiName(recordType);
                this.showModal = true;
            } catch (error) {
                console.error('Error opening modal:', error);
            }
        }
    }

    // Handle keyboard events for accessibility (Enter and Space keys)
    handleDirectLinkKeydown(event) {
        // Check if Enter or Space key was pressed
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleDirectLinkClick(event);
        }
    }

    // Handle closing the record details modal
    handleCloseModal() {
        this.showModal = false;
        this.modalRecordId = '';
        this.modalObjectApiName = '';
        this.modalError = '';
    }

    // Handle successful record form load
    handleRecordFormLoad(event) {
        this.modalError = '';
    }

    handleRefresh(){
        this.meetingType = '';
        this.meetingPurpose = '';
        this.meetingTitle = '';
        this.correlationId = '';
        this.payloadJSON = '';
        this.summaryRendered = false;
        this.isLoadingSummary = false;
        this.isLoadingData = false;
        this.showModal = false;
        this.dispatchEvent(new CustomEvent("componentrefreshed"));
    }

    // Handle record form error
    handleRecordFormError(event) {
        console.error('Record form error:', event.detail);
        this.modalError = event.detail.message || 'Unknown error loading record';
    }
}