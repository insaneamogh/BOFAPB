import { LightningElement, api, track } from 'lwc';
import initData from '@salesforce/apex/UST_MeetingPrepController.initData';
import getSummary from '@salesforce/apex/UST_MeetingPrepController.getSummary';

export default class MeetingPrep extends LightningElement {
    _recordId;
    _hasInit = false;
    @track correlationId;
    @track payloadJSON;
    @track error;
    @track summaryText = '';
    @track summaryError = '';

    @api
    get recordId() {
        return this._recordId;
    }

    set recordId(value) {
        this._recordId = value;
        if (value && !this._hasInit) {
            this._hasInit = true;
            this.fetchInitData();
        }
    }

    fetchInitData() {
        console.log('RecordID inside fetchInitData' + this.recordId); // Code review: remove consoles after unit testing
        initData({
                partyId: this.recordId,
                meetingType: 'Quarterly Check-In',
                windowDays: 90
            })
            .then(result => {
                this.correlationId = result.correlationId;
                this.payloadJSON = result.payloadJSON;

                console.log('This Dot PayLoad JSON' + this.payloadJSON); // Code review: remove consoles after unit testing

                this.handleGetSummary();
            })
            .catch(error => {
                this.error = error.body ? error.body.message : error.message;
            });
    }

    handleGetSummary() {
        console.log('Inside HandleGetSummary' + this.handleGetSummary);
        getSummary({
                payloadJSON: JSON.stringify(this.payloadJSON)
            })
            .then(result => {
                this.summaryText = result;
                this.summaryError = '';
                this.dispatchEvent(new CustomEvent('summaryloaded'));
            })
            .catch(error => {
                this.summaryText = '';
                this.summaryError = error.body ? error.body.message : error.message;
                this.dispatchEvent(new CustomEvent('summaryloaded'));
            });
    }

    get prettyPayload() {
        return this.payloadJSON ? JSON.stringify(this.payloadJSON, null, 2) : '';
    }
}