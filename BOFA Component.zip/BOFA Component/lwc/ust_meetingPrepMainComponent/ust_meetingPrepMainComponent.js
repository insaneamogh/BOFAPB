import { LightningElement, api, wire, track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

export default class MeetingPrepMainComponent extends LightningElement {
    // This will bind to Salesforce record context automatically
    @api recordId;
    @track showModal = true;
    @track meetingType;
    @track showMeetingPrep = false;
    @track fallbackRecordId;
    @track isLoadingSummary = false;

    // This will wire the current page info if recordId is not set by Salesforce
    @wire(CurrentPageReference)
    setCurrentPageReference(currentPageReference) {
        if (!this.recordId && currentPageReference && currentPageReference.attributes && currentPageReference.attributes.recordId) {
            this.fallbackRecordId = currentPageReference.attributes.recordId;
        }
    }

    get effectiveRecordId() {
        return this.recordId || this.fallbackRecordId;
    }

    meetingTypeOptions = [ //codereview: need to think on dynamic solution such that if more values are needed it should not require code deployment 
        { label: 'Quarterly check in', value: 'Quarterly check in' },
        { label: 'Adhoc', value: 'Adhoc' }
    ];

    handleMeetingTypeChange(event) {
        this.meetingType = event.detail.value;
    }

    handleCancel() {
        this.showModal = false;
        this.showMeetingPrep = false;
    }

    handleSave() {
        this.showModal = false;
        this.isLoadingSummary = true; 
        if (this.meetingType === 'Quarterly check in') {
            this.showMeetingPrep = true;
        } else {
            this.showMeetingPrep = false;
        }
    }

    handleSummaryLoaded() {
        this.isLoadingSummary = false;
    }
}