import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import initData from '@salesforce/apex/UST_CpMeetingPrepController.initData';
import getSummary from '@salesforce/apex/UST_CpMeetingPrepController.getSummary';

export default class CpMeetingPrep extends NavigationMixin(LightningElement) {
     _recordId;
     _hasInit = false;
    @api meetingType; // Accept meeting type from parent
    @api meetingPurpose; // Accept meeting purpose from parent
    @api selectedDataCategories; // Accept selected data categories from parent
    @track correlationId;
    @track payloadJSON;
    @track error;
     @track summaryText = '';
    @track summaryError = '';
    @track summaryRendered = false;
    @track showModal = false;
    @track modalRecordId = '';
    @track modalObjectApiName = '';
    @track modalError = '';
    @track parsedDataCategories = {};
    @track displayConfig = {
        cards: [],
        accordions: []
    };

     @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
        if (value && !this._hasInit) {
            this._hasInit = true;
            this.fetchInitData();
        }
    }



    fetchInitData() {
        initData({
            partyId: this.recordId,
            meetingType: 'Quarterly Check-In',
            windowDays: 90
        })
        .then(result => {
            this.correlationId = result.correlationId;
            this.payloadJSON = result.payloadJSON;

            this.parsePayloadData();
            this.initializeDisplayConfig();
            this.handleGetSummary();
        })
        .catch(error => {
            this.error = error.body ? error.body.message : error.message;
        });
    }

     handleGetSummary() {
        // Determine prompt template based on meeting type
        let promptTemplateName = 'CP_Test_Quarterly'; // Default for Quarterly
        if (this.meetingType === 'Adhoc') {
            promptTemplateName = 'CP_Test_Ad_Hoc';
        }

        getSummary({
            payloadJSON: JSON.stringify(this.payloadJSON),
            promptTemplateName: promptTemplateName,
            meetingType: this.meetingType,
            meetingPurpose: this.meetingPurpose,
            selectedDataCategories: this.selectedDataCategories
        })
        .then(result => {
            this.summaryText = result;
            this.summaryError = '';
            this.summaryRendered = false; // Reset to trigger re-rendering
            this.dispatchEvent(new CustomEvent('summaryloaded'));
        })
        .catch(error => {
            this.summaryText = '';
            this.summaryError = error.body ? error.body.message : error.message;
            this.dispatchEvent(new CustomEvent('summaryloaded'));
        });
    }

    get prettyPayload() {
        return this.payloadJSON ? JSON.stringify(this.payloadJSON, null, 2) : '';
    }

    // Dynamic data parsing to handle flexible JSON structures
    parsePayloadData() {
        if (!this.payloadJSON || !this.payloadJSON.r_PayloadJSON) {
            console.warn('No payload data to parse');
            return;
        }

        try {
            let rawPayload;
            if (typeof this.payloadJSON.r_PayloadJSON === 'string') {
                // Clean up common JSON issues before parsing
                const cleanedJSON = this.cleanupJSON(this.payloadJSON.r_PayloadJSON);
                rawPayload = JSON.parse(cleanedJSON);
            } else {
                // It's already an object (Salesforce Proxy object)
                rawPayload = this.payloadJSON.r_PayloadJSON;
            }

            const dataCategories = {};

            // Automatically detect data types and structure
            Object.keys(rawPayload).forEach(key => {
                const value = rawPayload[key];
                // Process and clean the data for better compatibility with standard components
                const processedData = this.processDataForStandardComponents(value);

                dataCategories[key] = {
                    key: key,
                    type: Array.isArray(value) ? 'array' : typeof value,
                    data: processedData,
                    count: Array.isArray(value) ? value.length : null,
                    fields: this.extractFieldNames(value),
                    displayName: this.formatDisplayName(key)
                };
            });

            this.parsedDataCategories = dataCategories;

        } catch (error) {
            console.error('Error parsing payload data:', error);
            this.parsedDataCategories = {};
        }
    }

    // Clean up common JSON formatting issues
    cleanupJSON(jsonString) {
        if (!jsonString || typeof jsonString !== 'string') {
            return jsonString;
        }

        return jsonString
            // Remove trailing commas before closing brackets and braces
            .replace(/,\s*]/g, ']')
            .replace(/,\s*}/g, '}')
            // Fix missing quotes around property names (if any)
            .replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":')
            // Fix missing quotes around certain values that should be strings
            .replace(/:(\s*)([^",\[\]{}\s]+)(\s*[,}\]])/g, (match, space1, value, space2) => {
                // Don't quote numbers, booleans, or null
                if (/^(true|false|null|\d+\.?\d*)$/i.test(value.trim())) {
                    return match;
                }
                return `:${space1}"${value}"${space2}`;
            })
            // Clean up any double escaping if present
            .replace(/\\"/g, '"')
            .trim();
    }

    // Process data to make it compatible with standard Lightning components
    processDataForStandardComponents(data) {
        if (Array.isArray(data)) {
            return data.map(item => this.processItemForStandardComponents(item));
        } else if (typeof data === 'object' && data !== null) {
            return this.processItemForStandardComponents(data);
        }
        return data;
    }

    // Process individual items to clean up data formatting
    processItemForStandardComponents(item) {
        if (typeof item !== 'object' || item === null) {
            return item;
        }

        const processedItem = {};
        Object.keys(item).forEach(key => {
            let value = item[key];

            // Handle date fields - convert readable date strings to Date objects
            if (this.isDateField(key, value)) {
                value = this.parseDate(value);
            }
            // Handle currency fields - ensure they're numbers (should already be fixed per user)
            else if (this.isCurrencyField(key, value)) {
                value = this.parseCurrency(value);
            }

            processedItem[key] = value;
        });

        return processedItem;
    }

    // Check if a field represents a date
    isDateField(fieldName, value) {
        const dateFieldNames = ['date', 'closedate', 'startdate', 'enddate', 'createddate', 'modifieddate'];
        const isDateFieldName = dateFieldNames.some(dateField =>
            fieldName.toLowerCase().includes(dateField)
        );

        // Also check if the value looks like a readable date string
        const isDateString = typeof value === 'string' &&
            /^[A-Za-z]+\s+\d{1,2},\s+\d{4}$/.test(value.trim()); // "November 23, 2022"

        return isDateFieldName || isDateString;
    }

    // Check if a field represents currency
    isCurrencyField(fieldName, value) {
        const currencyFieldNames = ['amount', 'balance', 'total', 'revenue', 'credit', 'deposit'];
        return currencyFieldNames.some(currencyField =>
            fieldName.toLowerCase().includes(currencyField)
        ) && (typeof value === 'string' && value.includes('$'));
    }

    // Parse date strings into Date objects
    parseDate(dateString) {
        if (!dateString || typeof dateString !== 'string') {
            return dateString;
        }

        try {
            // Handle "November 23, 2022" format
            const date = new Date(dateString);

            // Verify the date is valid
            if (isNaN(date.getTime())) {
                console.warn('Invalid date string:', dateString);
                return dateString; // Return original if parsing fails
            }

            return date;
        } catch (error) {
            console.warn('Error parsing date:', dateString, error);
            return dateString; // Return original if parsing fails
        }
    }

    // Parse currency strings into numbers
    parseCurrency(currencyString) {
        if (typeof currencyString === 'number') {
            return currencyString;
        }

        if (typeof currencyString === 'string') {
            // Remove currency symbols and commas, then parse
            const numStr = currencyString.replace(/[$,]/g, '');
            const num = parseFloat(numStr);
            return isNaN(num) ? 0 : num;
        }

        return 0;
    }

    // Extract field names from data for flexible rendering
    extractFieldNames(data) {
        if (Array.isArray(data) && data.length > 0) {
            // Get all unique field names from array items
            const allFields = new Set();
            data.forEach(item => {
                if (typeof item === 'object' && item !== null) {
                    Object.keys(item).forEach(field => allFields.add(field));
                }
            });
            return Array.from(allFields);
        }
        if (typeof data === 'object' && data !== null) {
            return Object.keys(data);
        }
        return [];
    }

    // Format key names for display (convert camelCase/PascalCase to readable format)
    formatDisplayName(key) {
        return key
            .replace(/([A-Z])/g, ' $1') // Add space before capital letters
            .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
            .trim();
    }

    // Initialize display configuration based on parsed data
    initializeDisplayConfig() {
        const cards = [];
        const accordions = [];

        // Default configuration mapping - this could be made configurable later
        Object.keys(this.parsedDataCategories).forEach(key => {
            const category = this.parsedDataCategories[key];

            // Decide whether to show as card or accordion based on data characteristics
            if (this.shouldShowAsCard(category)) {
                cards.push(this.createCardConfig(category));
            }

            // Most data can also be shown as accordion (detailed view)
            if (this.shouldShowAsAccordion(category)) {
                accordions.push(this.createAccordionConfig(category));
            }
        });

        this.displayConfig = { cards, accordions };
    }

    // Determine if data should be displayed as a card
    shouldShowAsCard(category) {
        // Show as card if:
        // 1. It's a financial summary (object with numeric values)
        // 2. It's a small array (< 6 items) with important data - BUT NOT Opportunities (they get datatable)
        // 3. It's a single important metric

        if (category.type === 'object' && category.key.toLowerCase().includes('financial')) {
            return true;
        }

        // Skip opportunities for cards since they now use datatable
        if (category.key === 'Opportunities') {
            return false;
        }

        if (category.type === 'array' && category.count > 0 && category.count <= 5) {
            return ['Recent Activities', 'Tasks'].includes(category.key);
        }

        return false;
    }

    // Determine if data should be displayed as an accordion
    shouldShowAsAccordion(category) {
        // Show as accordion if:
        // 1. It's an array with items (including Opportunities which will use datatable inside accordion)
        // 2. It's an object with multiple properties
        // 3. It's detailed data that takes up space

        return (category.type === 'array' && category.count > 0) ||
               (category.type === 'object' && category.fields.length > 0);
    }

    // Create card configuration
    createCardConfig(category) {
        return {
            key: category.key,
            displayName: category.displayName,
            type: category.type,
            data: category.data,
            count: category.count,
            icon: this.getIconForCategory(category.key),
            priority: this.getPriorityForCategory(category.key)
        };
    }

    // Create accordion configuration
    createAccordionConfig(category) {
        return {
            key: category.key,
            displayName: category.displayName,
            type: category.type,
            data: category.data,
            count: category.count,
            fields: category.fields,
            icon: this.getIconForCategory(category.key),
            priority: this.getPriorityForCategory(category.key),
            recordType: this.getRecordTypeForCategory(category.key),
            useDataTable: category.key === 'Opportunities' // Flag to use datatable instead of list
        };
    }

    // Get appropriate icon for data category
    getIconForCategory(key) {
        const iconMap = {
            'Financial Summary': 'utility:money',
            'Opportunities': 'standard:opportunity',
            'Employment': 'utility:work',
            'Education': 'utility:education',
            'Meaningful Interactions': 'utility:comments',
            'ClientServiceInteractions': 'utility:customer_service',
            'Previous Interactions': 'utility:comments'
        };

        return iconMap[key] || 'utility:list';
    }

    // Get priority for sorting (lower number = higher priority)
    getPriorityForCategory(key) {
        const priorityMap = {
            'Financial Summary': 1,
            'Opportunities': 2,
            'Employment': 3,
            'Education': 4,
            'Meaningful Interactions': 5,
            'ClientServiceInteractions': 6
        };

        return priorityMap[key] || 10;
    }

    // Get record type for linking
    getRecordTypeForCategory(key) {
        const recordTypeMap = {
            'Opportunities': 'Opportunity',
            'Employment': 'Contact', // or custom object
            'Education': 'Contact', // or custom object
            'Meaningful Interactions': 'Task',
            'ClientServiceInteractions': 'Case'
        };

        return recordTypeMap[key] || null;
    }


    // Computed properties for sorted display items
    get sortedCards() {
        if (!this.displayConfig.cards) return [];
        return [...this.displayConfig.cards].sort((a, b) => a.priority - b.priority);
    }

    get sortedAccordions() {
        if (!this.displayConfig.accordions) return [];
        return [...this.displayConfig.accordions].sort((a, b) => a.priority - b.priority);
    }

    get hasCards() {
        return this.sortedCards.length > 0;
    }

    get hasAccordions() {
        return this.sortedAccordions.length > 0;
    }



    // Handle record click events from child components
    handleRecordClick(event) {
        const { recordId, recordType } = event.detail;

        if (recordId && recordId.length >= 15) {
            try {
                this.modalRecordId = recordId;
                this.modalObjectApiName = this.getObjectApiName(recordType);
                this.showModal = true;
            } catch (error) {
                console.error('Error opening modal from dynamic component:', error);
            }
        }
    }

    // Map record types from our links to proper Object API Names for lightning-record-form
    getObjectApiName(recordType) {
        const objectMapping = {
            'Account': 'Account',
            'Contact': 'Contact',
            'Opportunity': 'Opportunity',
            'Case': 'Case',
            'Lead': 'Lead',
            'Task': 'Task',
            'Event': 'Event',
            'Campaign': 'Campaign',
            'Product2': 'Product2',
            // Add more mappings as needed for custom objects
        };

        return objectMapping[recordType] || recordType;
    }

    renderedCallback() {
        // Render the summary content manually to preserve all HTML attributes
        if (this.summaryText && !this.summaryRendered) {
            const summaryContainer = this.template.querySelector('.summary-content');
            if (summaryContainer) {
                // Set the HTML content directly
                summaryContainer.innerHTML = this.summaryText;

                // Apply SLDS styling classes to HTML formatting elements
                this.applySLDSStylestoSummary(summaryContainer);

                // Add event listeners to all record links
                const recordLinks = summaryContainer.querySelectorAll('a[data-record-id]');
                recordLinks.forEach(link => {
                    // Remove any existing listeners to prevent duplicates
                    link.removeEventListener('click', this.boundHandleLinkClick);

                    // Add click event listener
                    this.boundHandleLinkClick = this.handleDirectLinkClick.bind(this);
                    link.addEventListener('click', this.boundHandleLinkClick);

                    // Add keyboard event listener for accessibility
                    link.removeEventListener('keydown', this.boundHandleLinkKeydown);
                    this.boundHandleLinkKeydown = this.handleDirectLinkKeydown.bind(this);
                    link.addEventListener('keydown', this.boundHandleLinkKeydown);
                });

                this.summaryRendered = true;
            }
        }
    }

    // Apply SLDS styling classes to HTML elements in the summary
    applySLDSStylestoSummary(container) {
        if (!container) return;

        // Style headings
        container.querySelectorAll('h1').forEach(el => {
            el.className = 'slds-text-heading_large slds-m-bottom_small slds-text-color_default';
        });

        container.querySelectorAll('h2').forEach(el => {
            el.className = 'slds-text-heading_medium slds-m-bottom_small slds-text-color_default';
        });

        container.querySelectorAll('h3').forEach(el => {
            el.className = 'slds-text-heading_small slds-m-bottom_x-small slds-text-color_default';
        });

        container.querySelectorAll('h4').forEach(el => {
            el.className = 'slds-text-body_regular slds-text-font_monospace slds-m-bottom_x-small slds-text-color_default';
        });

        // Style lists
        container.querySelectorAll('ul').forEach(el => {
            el.className = 'slds-list_dotted slds-m-bottom_medium slds-m-left_large';
        });

        container.querySelectorAll('ol').forEach(el => {
            el.className = 'slds-list_ordered slds-m-bottom_medium slds-m-left_large';
        });

        // Style list items
        container.querySelectorAll('li').forEach(el => {
            el.className = 'slds-item slds-m-bottom_x-small';
        });

        // Style paragraphs
        container.querySelectorAll('p').forEach(el => {
            el.className = 'slds-text-body_regular slds-m-bottom_small';
        });

        // Style strong/bold text
        container.querySelectorAll('strong, b').forEach(el => {
            el.className = 'slds-text-font_monospace';
        });

        // Style emphasis/italic text
        container.querySelectorAll('em, i').forEach(el => {
            el.className = 'slds-text-font_monospace';
        });
    }

    disconnectedCallback() {
        // Clean up event listeners to prevent memory leaks
        const summaryContainer = this.template.querySelector('.summary-content');
        if (summaryContainer) {
            const recordLinks = summaryContainer.querySelectorAll('a[data-record-id]');
            recordLinks.forEach(link => {
                link.removeEventListener('click', this.boundHandleLinkClick);
                link.removeEventListener('keydown', this.boundHandleLinkKeydown);
            });
        }
    }

    // Handle direct clicks on record links (bound to individual link elements)
    handleDirectLinkClick(event) {
        // Prevent default anchor behavior
        event.preventDefault();
        event.stopPropagation();

        const link = event.currentTarget; // Use currentTarget since we bound to the specific link
        const recordId = link.dataset.recordId;
        const recordType = link.dataset.recordType;

        if (recordId && recordId.length >= 15) {
            try {
                this.modalRecordId = recordId;
                this.modalObjectApiName = this.getObjectApiName(recordType);
                this.showModal = true;
            } catch (error) {
                console.error('Error opening modal:', error);
            }
        }
    }

    // Handle keyboard events for accessibility (Enter and Space keys)
    handleDirectLinkKeydown(event) {
        // Check if Enter or Space key was pressed
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleDirectLinkClick(event);
        }
    }

    // Handle closing the record details modal
    handleCloseModal() {
        this.showModal = false;
        this.modalRecordId = '';
        this.modalObjectApiName = '';
        this.modalError = '';
    }

    // Handle successful record form load
    handleRecordFormLoad(event) {
        this.modalError = '';
    }

    // Handle record form error
    handleRecordFormError(event) {
        console.error('Record form error:', event.detail);
        this.modalError = event.detail.message || 'Unknown error loading record';
    }
}